#include <stdio.h>
#include<string.h>
#include <pthread.h>
#include<stdlib.h>
#include<unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <errno.h>

#define NUM 32
pid_t pid[NUM];
static int stop_running;

int main(int argc, char **argv)
{
	int i = 0;
	int status = 0;
	int err;
	int priority = -19;
	int ans = 0;
	struct sched_param param;

    	while (i < NUM) {
        	pid[i] = fork();
		if (pid[i] >= 0) { // Fork worked
			if (pid[i] == 0) //Child
				while (1) {
					if (stop_running)
						break;
				}
			else
				printf("child %d created\n", pid[i]);
		} else {
			printf("Could not fork\n");
			return 0;
		}
        	i++;
    	}


	sleep(5);

	printf("Hit return to stop all threads\n");

	fscanf(stdin, "%d", &ans);

	stop_running = 1;

	for (i = 0; i < NUM; i++)
		waitpid(pid[i], &status, WUNTRACED | WCONTINUED);

	printf("%s Exiting\n", __func__);

	return 0;
}
