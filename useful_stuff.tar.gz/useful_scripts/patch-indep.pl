#!/usr/bin/perl

# check stg patch dependency
# print which patches can apply to the top of stack on their own
# by Rob Elliott
# version 0.1
#
use strict;

# read series
my %series;
open SERIES, "stg series|";
while (<SERIES>) {
	chomp;
	my ($patch) = /^\S (\S*)$/;
	($series{$patch}) = 0;
}
close SERIES;
printf("processing %d patches\n", scalar keys %series);

# push each patch individually
my @result;
my $conflict;
my $empty;
my $unknown;

foreach (sort keys %series) {
	my $result = 0;	# 0=unknown/good, 1=empty, 2=conflict
	my $patch = $_;
	my $notblank = 0;

	# Pushing patch "h1" ... done (unmodified)
	# Pushing patch "hpsa-bump-driver-version-again" ... done (conflict)
	open PUSH, "stg push $patch 2>&1|";
	while (<PUSH>) {
		$notblank = 1;
		if (/^Error.*conflict/) {
			#print "patch $patch had conflict\n";
			$result = 2;
			last;
		} elsif (/^No patch applied/) {
			#print "patch $patch was empty\n";
			$result = 1;
			last;
		} else {
			#print "ignoring: $_\n";
		}
	}
	close PUSH;

	if ($result == 2) {
		#print "patch $patch: undoing after conflict\n";
		system "stg reset --hard";
		system "stg undo";
		system "stg pop -a";
		$conflict++;
		# reset + pop leaves the patch empty, which is not good; reset + undo is correct
	} elsif ($result == 1) {
		#print "patch $patch: empty\n";
		system "stg undo";
		system "stg pop -a";
		$empty++;
	} else {
		#print "patch $patch: unknown\n";
		$unknown++;
	}

	$series{$patch} = $result;
	if ($notblank == 0) {
		system "stg pop -a";
	}
}

print "\nEmpty patches:\n";
foreach (sort keys %series) {
	if ($series{$_} == 1) {
		print "$_\n";
	}
}

print "\nDependent patches:\n";
foreach (sort keys %series) {
	if ($series{$_} == 2) {
		print "$_\n";
	}
}

print "\nIndependent patches:\n";
foreach (sort keys %series) {
	if ($series{$_} == 0) {
		print "$_\n";
	}
}

