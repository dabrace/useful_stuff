#include <stdio.h>

#define ACPI_UTILITIES                  0x00000001
#define ACPI_HARDWARE                   0x00000002
#define ACPI_EVENTS                     0x00000004
#define ACPI_TABLES                     0x00000008
#define ACPI_NAMESPACE                  0x00000010
#define ACPI_PARSER                     0x00000020
#define ACPI_DISPATCHER                 0x00000040
#define ACPI_EXECUTER                   0x00000080
#define ACPI_RESOURCES                  0x00000100
#define ACPI_CA_DEBUGGER                0x00000200
#define ACPI_OS_SERVICES                0x00000400
#define ACPI_CA_DISASSEMBLER            0x00000800
#define ACPI_COMPILER                   0x00001000
#define ACPI_TOOLS                      0x00002000
#define ACPI_BUS_COMPONENT              0x00010000
#define ACPI_AC_COMPONENT               0x00020000
#define ACPI_BATTERY_COMPONENT          0x00040000
#define ACPI_BUTTON_COMPONENT           0x00080000
#define ACPI_SBS_COMPONENT              0x00100000
#define ACPI_FAN_COMPONENT              0x00200000
#define ACPI_PCI_COMPONENT              0x00400000
#define ACPI_POWER_COMPONENT            0x00800000
#define ACPI_CONTAINER_COMPONENT        0x01000000
#define ACPI_SYSTEM_COMPONENT           0x02000000
#define ACPI_THERMAL_COMPONENT          0x04000000
#define ACPI_MEMORY_DEVICE_COMPONENT    0x08000000
#define ACPI_VIDEO_COMPONENT            0x10000000
#define ACPI_PROCESSOR_COMPONENT        0x20000000

#define ACPI_LV_INIT                    0x00000001
#define ACPI_LV_DEBUG_OBJECT            0x00000002
#define ACPI_LV_INFO                    0x00000004
#define ACPI_LV_INIT_NAMES              0x00000020
#define ACPI_LV_PARSE                   0x00000040
#define ACPI_LV_LOAD                    0x00000080
#define ACPI_LV_DISPATCH                0x00000100
#define ACPI_LV_EXEC                    0x00000200
#define ACPI_LV_NAMES                   0x00000400
#define ACPI_LV_OPREGION                0x00000800
#define ACPI_LV_BFIELD                  0x00001000
#define ACPI_LV_TABLES                  0x00002000
#define ACPI_LV_VALUES                  0x00004000
#define ACPI_LV_OBJECTS                 0x00008000
#define ACPI_LV_RESOURCES               0x00010000
#define ACPI_LV_USER_REQUESTS           0x00020000
#define ACPI_LV_PACKAGE                 0x00040000
#define ACPI_LV_ALLOCATIONS             0x00100000
#define ACPI_LV_FUNCTIONS               0x00200000
#define ACPI_LV_OPTIMIZATIONS           0x00400000
#define ACPI_LV_MUTEX                   0x01000000
#define ACPI_LV_THREADS                 0x02000000
#define ACPI_LV_IO                      0x04000000
#define ACPI_LV_INTERRUPTS              0x08000000
#define ACPI_LV_AML_DISASSEMBLE         0x10000000
#define ACPI_LV_VERBOSE_INFO            0x20000000
#define ACPI_LV_FULL_TABLES             0x40000000
#define ACPI_LV_EVENTS                  0x80000000

int main(int argc, char **argv)
{
        unsigned long debug_layer = 
                ACPI_HARDWARE |
		ACPI_TABLES |
                ACPI_EXECUTER |
                ACPI_PCI_COMPONENT |
                ACPI_MEMORY_DEVICE_COMPONENT;
        unsigned long debug_level = 
                ACPI_LV_EXEC |
                ACPI_LV_MUTEX |
                ACPI_LV_AML_DISASSEMBLE |
		ACPI_LV_INTERRUPTS |
                ACPI_LV_VERBOSE_INFO;

        printf("echo 0x%lx > /sys/module/acpi/parameters/debug_layer\n", debug_layer);
        printf("echo 0x%lx > /sys/module/acpi/parameters/debug_level\n", debug_level);
}
