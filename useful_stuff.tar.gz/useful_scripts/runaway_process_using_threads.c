#include <stdio.h>
#include<string.h>
#include <pthread.h>
#include<stdlib.h>
#include<unistd.h>

#define NUM 32
pthread_t tid[NUM];

void *doKeepCPUBusy(void *arg)
{
	int i = 0;
	pthread_t id = pthread_self();

	for (i = 0; i < NUM; i++) {
		if (pthread_equal(id,tid[i])) {
			printf("\n thread %02d id=%lx processing\n", i, id);
			sched_get_priority_max(SCHED_FIFO);
		}
	}

	while (1) {
	}
}

int main(int argc, char **argv)
{
	int i = 0;
	int err;
	int priority = -19;
	int ans = 0;
	struct sched_param param;

    	while (i < NUM) {
        	err = pthread_create(&(tid[i]), NULL, &doKeepCPUBusy, NULL);
        	if (err != 0) {
            		printf("\ncan't create thread :[%s]", strerror(err));
        	} else  {
            		printf("\n Thread %02d created successfully\n", i);
			param.sched_priority = priority;
			pthread_setschedparam(tid[i], priority, &param);
		}

        	i++;
    	}

	sleep(5);

	printf("Hit return to stop all threads\n");

	fscanf(stdin, "%d", &ans);

	for (i = 0; i < NUM; i++) {
		pthread_join(tid[i], NULL);
	}

	printf("%s Exiting\n", __func__);

	return 0;
}
