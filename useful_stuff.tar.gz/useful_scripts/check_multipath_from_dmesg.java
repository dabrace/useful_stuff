import java.lang.*;
import java.util.*;

class multipath_device
{
	String[] device_name;
}

public class check_multipath_from_dmesg
{

	public static void main(String[] args) {
		String line;
		Scanner scan = new Scanner(System.in);

		line = scan.nextLine();

		System.out.println("I read: " + line);
	}
};
