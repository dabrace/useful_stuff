#!/usr/bin/env ruby

require 'tempfile'

class Structure
  attr_reader :filename

  def initialize(filename)
    @filename = filename
    @file = get_structure_info_file
  end

  def get_info(name)
    s = []
    @file.rewind
    @file.each do |line|
      s << line if line =~ /^struct #{name} / ... line =~ /^};/
    end
    s
  end

private

  def get_structure_info_file
    file = Tempfile.new('')
    puts "Getting symbols from #{@filename}"
    `pahole -aV #{@filename} > #{file.path}`
    file
  end
end

def equal(left, right)
  !left.empty? && !right.empty? && left == right
end

def compare(left_struct, left_name, right_struct, right_name)
  left = left_struct.get_info(left_name)
  right = right_struct.get_info(right_name)
  if equal(left, right)
    puts "passed"
    true
  else
    puts "failed"
    puts "#{left_struct.filename}:", left, "\n"
    puts "#{right_struct.filename}:", right, "\n"
    false
  end
end


left_struct = Structure.new(ARGV[0])
right_struct = Structure.new(ARGV[1])

pass = true

File.open(ARGV[2], 'r').each_line do |struct|
  left_name, right_name = struct.chomp!.split(' ')
  print "Checking #{left_name}/#{right_name}: "
  pass &= compare(left_struct, left_name, right_struct, right_name)
end

exit pass ? 0 : 1
