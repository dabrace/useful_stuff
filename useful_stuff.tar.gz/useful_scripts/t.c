#include <stdio.h>

struct u {
	union {
		struct {
			unsigned char a;
		} f1;
		struct {
			unsigned char b;
		} f2;
	} e;
};
int main(int argc, char **argv)
{

	struct u uppa_u;

	printf("sizeof uppa_u = %ld\n", sizeof(struct u));
	return 0;
}
