#!/usr/bin/perl
######################################################################
# Function VerifySelection
######################################################################
# Purpose:
#     If choice is a member array, return true, otherwise, false.
# Example: 
#	&VerifySelection($choice, $selections) || die("Unknown choice $choice\n");
######################################################################
sub VerifySelection {

        local($choice, %array)=@_;
	foreach $item (%array) {
		if ($choice eq $item) {
			return 1;
		}
	}
	return 0;
} # end Function VerifySelection

##############
# Required Line
###############
1;

