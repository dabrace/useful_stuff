#!/bin/bash -x

version='$Header: /home/rwright/tools/RCS/fotest.sh,v 1.11 2018/08/06 23:55:36 rwright Exp $'
purpose1='Iterate expect script to shutdown and restart storage controller'
purpose2='Why use shell?  Because msa2040 is prone to drop the ssh connection during restart.'
purpose3='Also this gives a framework to check for journalctl errors between shorter expect iterations.'
shopt -s extglob
shopt


# protect running script against nameservice glitches by
# mapping host to ip once at startup
function host2ip {
	host=$1
	ns=hou.lab.pmc-sierra.bc.ca
	ip=$(nslookup $host $ns|awk -v nseen=0 '\
			$1=="Name:"{nseen++}\
			$1=="Address:"&&nseen==1{print $NF}')
	if [[ -n "$ip" ]]; then
		echo $ip
		return
	fi
	echo "Host $host not found by $ns" 1>&2
	exit 1
}

# Currently, this function expects 2 paths for each test lun.
# Conceptually we could establish these parameters at startup and
# pass the values into the function, but I wrote this in a hurry.
function wait_for_all_paths {
    mpathlist=$*
    let nmapper=32767
    let nscsi=$((nmapper*2))
    let tmapper=$#
    let tscsi=$((tmapper*2))
    of=/tmp/multipath-ll-$$.txt
    while [[ $nmapper != $tmapper || $nscsi != $tscsi ]]; do
	sleep 5
	cp /dev/null $of
	for x in $mpathlist; do
		multipath -ll $x >> $of
	done
	let nmapper=$(grep ' dm-[0-9][0-9]* ' $of|wc -l)
	let nscsi=$(grep -e '- [0-9]*:[0-9]*:[0-9]*:[0-9]*[ ]*sd.*active.*ready' $of|wc -l)
    done
    # dont rm $of - it may provide a useful clue
    return 0
}

#!/bin/bash

# Find /dev/mapper devices for the expected test LUNS
# Basically, this exists to exclude single-path devices under /dev/mapper control
function find_multipath_test_luns {
	for x in 0 1 2 3 4; do
        	findfs LABEL=EXT0$x
        	findfs LABEL=XFS0$x
	done
	findfs LABEL=XFSXL
}

function find_multipath_test_wwids {
	luns=$(find_multipath_test_luns)
	for x in $luns; do		        
		# remove /dev/mapper prefix
		nmapper=${x##*/}
		# remove partition suffix
		# this pattern handles sles using -part#
		npart=${nmapper%?part*}
		# this pattern handles rhel using p#
		npart=${npart%p+([0-9])}
		echo $npart
	done
}

# the expect script should do this: 
#  connect to host arg1
#  shutdown controller indicated by arg 2
#  attempt to do that for arg3 iterations 

# test hosts and fail ports in this order
# because msa2040 does not like to run a fail on the port to which session connects
hn=$(hostname)
hn=clou
hn=trafferth
domain=hou.lab.pmc-sierra.bc.ca
# Finding IP addresses
# nmap 10.238.*.* > nmap.out 2>&1
# Look for name givin to the P2000 or MSA storage device
case X$hn in
X)
	echo "hostname not set" 1>&2; exit 1;;
clou)
	#ahost=msa2040-sas1.$domain; bhost=msa2040-sas1b.$domain;;
	ahost=10.238.0.40; bhost=10.238.0.41;;
trafferth)
	#ahost=10.238.7.211; bhost=10.238.10.229;;
	ahost=10.238.12.85; bhost=10.238.12.86;;
	#HP-MSA-Storage-10897f.pdev.net (10.238.12.85)
	#HP-MSA-Storage-108381.pdev.net (10.238.12.86)
Xtanerite02)
	ahost=p2ksas1a.$domain;     bhost=p2ksas1b.$domain;;
*)
	ahost=${1:-"Need storage controller A port"}; bhost=${2:-"Need storage controller B port"};;
esac
#aport=$(host2ip $ahost)
#bport=$(host2ip $bhost)
aport=10.238.12.85
bport=10.238.112.86

let running_on_SUT=0

wwids=$(find_multipath_test_wwids)

let iter=0

while [[ 6 != 9 ]]; do
	let iter=1+$iter
        echo "=============================================================================================="
        echo "$0 - STARTING ITERATION $iter at `date`"
        echo "=============================================================================================="
	echo iteration $iter at $(date)

	# intent here was to run between 1 and 4 iterations of the expect script on each controller
	# niter is a random byte formatted as ascii unsigned int
	# niter=$(od --read-bytes=1 --address-radix=n --format=u /dev/urandom)
	# let niter=$(((niter%4)+1))

	# however, hooking in some validation of the mulitpath state
	# on the SUT makes it better to do only one failover cycle,
	# this way we check between each cycle.
	let niter=1

	date

	wait_for_all_paths $wwids
	let s=1
	let inner_iter=1
	while [[ $s -ne 0 ]]; do
            echo "------------------------------------------------------------------------------------------"
	    echo "SC - B. starting fotest.exp (iteration $iter) (inner_iter $inner_iter) RC=$s at `date`"
            echo "------------------------------------------------------------------------------------------"
	    ./fotest.exp $aport b $niter
	    s=$?
	    let inner_iter=1+$inner_iter
	done

	sleep 30

	date

	wait_for_all_paths $wwids
	let s=1
	let inner_iter=1
	while [[ $s -ne 0 ]]; do
            echo "------------------------------------------------------------------------------------------"
	    echo "SC - A. starting fotest.exp (iteration $iter) (inner_iter = $inner_iter) RC=$s at `date`"
            echo "------------------------------------------------------------------------------------------"
	    ./fotest.exp $bport a $niter
	    s=$?
	    let inner_iter=1+$inner_iter
	done	

	sleep 30
done
