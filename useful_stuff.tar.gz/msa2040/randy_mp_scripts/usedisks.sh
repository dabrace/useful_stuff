#!/bin/bash -x
version='$Header: /home/rwright/tools/RCS/usedisks.sh,v 1.8 2018/07/20 00:30:34 rwright Exp $'

function umount_mount {
    # umount to blow away caches - also assures nothing is hung, or hangs itself
    list="$1"
    again=""
    for fs in $list; do
	umount $fs || again+="$fs "
    done
    for fs in $again; do
	until umount $fs; do sleep 2; done
    done
    sleep 2
    again=""
    for fs in $list; do
	mount $fs  || again+="$fs "
    done
    for fs in $again; do
	until  mount $fs; do sleep 2; done
    done
}

[[ -f $HOME/debug_settings.sh ]] && . $HOME/debug_settings.sh
cd /mnt
let slowcp=0
let iteration=0

# finds all lines in fstab with test filesystems
labels=$(awk '/^LABEL=XFS/||/^LABEL=EXT/{sub("LABEL=","");print $1}' < /etc/fstab)
if [[ -z "$labels" ]]; then
    echo No test luns 1>&2
    exit 1
fi
let errors=0
dmlist=""
for label in $labels; do
    if dn=$(findfs LABEL=$label); then
	dmlist+="$dn "
    else
	let errors+=1
    fi
done

if [[ $errors > 0 ]]; then
    echo Something is missing 1>&2
    exit 1
fi

while [[ 1 -eq 1 ]]; do
    let iteration=1+$iteration

    echo "======================================================="
    echo "$0 STARTING ITERATION $iteration at `date`"
    echo "======================================================="
    date
    rm -rf XFS0*/EXT0* & rm -rf EXT0*/XFS0* & rm -rf XFSXL/EXT0* & rm -rf XFSXL/XFS0* &
    wait; date; sync; date
    list="$dmlist"

    umount_mount "$dmlist"

    for fs in $list; do
	FS=`basename $fs`
    	for n in 00 01 02 03 04; do
		echo "DON>>>/mnt/$FS/EXT$n"
		cp -Pr /etc /mnt/$FS/EXT$n &
    	done
    done
    wait; date; sync; date

    umount_mount "$dmlist"

    echo "COPY FROM MPATH TO SAME MPATH different directory `date`"
    for fs_origin in $list; do
	FS_origin=`basename $fs_origin`
    	for n in 00 01 02 03 04; do
		echo "BRACE>>>/mnt/$FS_origin/EXT$n"
		cp -Pr /mnt/$FS_origin/EXT$n /mnt/$FS_origin/XFS$n &
    	done
    done
    wait; date; sync; date

    echo "COPY FROM ONE MPATH TO ANOTHER MPATH `date`"
    for fs_origin in $list; do
	    FS_origin=`basename $fs_origin`
	    for fs_dest in $list; do
		    if [ $fs_origin = $fs_dest ]
	            then
			    continue
		    fi
	            FS_dest=`basename $fs_dest`
    	            for n in 00 01 02 03 04; do
			    echo "----------------------------------------------------------------"
		            echo "BRACE_DON>>>/mnt/$FS_origin/EXT$n /mnt/$FS_dest/XFS$n `date`"
			    echo "----------------------------------------------------------------"
			    #rm -rf /mnt/$FS_dest/XFS$n
		            cp -Prf /mnt/$FS_origin/EXT$n /mnt/$FS_dest/XFS$n &
    	            done
	    done
	    wait; date; sync; date
    done
    wait; date; sync; date

    umount_mount "$dmlist"

#    if [[ $slowcp > 0 ]]; then
#	cp -pr EXT0* XFSXL &
#	if [[ $slowcp > 1 ]]; then
#	    cp -pr XFS0* XFSXL &
#	fi
#	wait; date; sync; date
#    fi
done
