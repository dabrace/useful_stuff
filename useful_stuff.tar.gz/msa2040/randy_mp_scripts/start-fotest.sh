#!/bin/bash -x
version='$Header: /home/rwright/tools/RCS/start-fotest.sh,v 1.4 2017/02/28 18:29:24 rwright Exp $'
purpose='start multiple test scripts'
scripts="./usedisks.sh ./fotest.sh"
for s in $scripts; do
    if [[ ! -f $s ]]; then
	echo missing test script $s 1>&2
	exit 1
    fi
done
p1=${1:-10}
let slp=$p1
echo starting test in $slp seconds
ds=$(date +%Y%m%d-%H%M)
sleep $slp
for s in $scripts; do
    # bn is basename in case script had a ".sh" on the end
    bn=${s%%.sh}
    nohup $s >& $bn-$ds.txt &
    sleep 5
done
