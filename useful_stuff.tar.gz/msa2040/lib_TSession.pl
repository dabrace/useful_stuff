#!/usr/bin/perl
######################################################################
# Function TSession
######################################################################
# Purpose:
#       Create a telnet Session 
#
# Example: 
#	&TSession($TTY); 
# Params:
#	TTY - name to lookup in DB_* files to get connection specific.
######################################################################
# Origin: Scott Teel 2011
sub TSession {

        local($TTY)=@_;

	# Creating telnet session 
	if ($TTY =~ /telnet/) {

		($junk, $host, $port) = split(' ', $TTY);

		if ($port == "" ) {
			# Direct telnet doesn't require a port number.
			print "Connecting to $host\n";
			$Session = new Net::Telnet ( Timeout=>90, Errmode=>'die', Prompt=> '/\$ $/i');
			$InLogFile = $Session->input_log("/tmp/telnet.in.log");
			$OutLogFile = $Session->output_log("/tmp/telnet.out.log");
			$Session->open($host);
			$Session->waitfor('/Login: $/i');
			#Set login and password using telnet credentials.
			$SQ_LOGIN 	= $ARRAYLOG;
			$SQ_PW 		= $ARRAYPW;
		} 
		else { 
			print "Establish port session to $host port $port.\n";
			$Session = new Net::Telnet ( Timeout=>90, Errmode=>'die', Prompt=> '/\$ $/i',Port=>$port);
			$Session->open($host);
			$Session->waitfor('/Username: $/i');
			#Set login and password using serial console server credentials
			$SQ_LOGIN 	= $SCS_Login;
			$SQ_PW	 	= $SCS_PW;
		}
		$Session->print(${SQ_LOGIN});
		$Session->waitfor('/Password: $/i');
		$Session->print(${SQ_PW});
		$Session->print('');
		sleep $POSTLOGINWAIT;

		return $Session;
	}
	
	return $TTY;

} # end Function TSession

##############
# Required Line
###############
1;

