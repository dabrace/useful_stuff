#!/usr/bin/perl
use Net::Telnet;
######################################################################
# SHControllers
######################################################################
######################################################################
# Origin: 06/2009 S.Teel
######################################################################
#
# Assumptions:
#
# 1. We have minicom sessions or serial console sessions 
#	set up as specified in CommPorts array below.
#
######################################################################
#
# Some important Vars:
push(@INC, '/home/brace/bin/msa2040');
require 'lib_TSession.pl';
require 'lib_VerifySelection.pl';
require 'lib_Usage.pl';
require 'DB_CommonInfrastructure.pl';
######################################################################
my $Purpose = "Restart or shutdown specified external array controller 	\n";
$Purpose .=	"using a Telnet session through Serial Console Server	\n";
$Purpose .=	"or using tty via minicom & direct serial connection.	\n";
$Purpose .=	"Usage:							\n";
$Purpose .=	"$0 SASenv DEV Action Controller			\n";
$Purpose .=	"\t Performs the specified action on the specified controller.\n";
$Purpose .=	"\t\t  							\n";
$Purpose .=	"\t Where:						\n";
$Purpose .=	"\t\t SASenv		SAS environment to use (3Gb|6Gb)\n";
$Purpose .=	"\t\t DEV		Comm device to use like /dev/ttyS0, Seahawk1, or Seahawk1BTelnet\n";
$Purpose .=	"\t\t Action		shutdown|restart|restart_mc	\n";
$Purpose .=	"\t\t Controller   	A|B|both			\n";
$Purpose .=	"\t\t  							\n";
$Purpose .=	"\t Sample 1:						\n";
$Purpose .=	"\t\t $0 3Gb /dev/ttyS1 shutdown B			\n";
$Purpose .=	"\t\t Shuts down controller B on device connected through /dev/ttyS1 \n";
$Purpose .=	"\t\t  							\n";
$Purpose .=	"\t Sample 2:						\n";
$Purpose .=	"\t\t $0 3Gb Seahawk1BTelnet restart A			\n";
$Purpose .=	"\t\t Restarts controller A on device by establishing a telnet session \n";
$Purpose .=	"\t\t through the hostname and device port information indexed by name Seahawk1BTelnet.\n";
$Purpose .=	"\t\t  							\n";

$VMWARE_LOG="/proc/vmware/log";



# Get the parameters
( 
	$SASENV,
	$DEV,
	$ACTION,
	$CONTROLLER
)	=@ARGV;

# Check parameters:
if (	($SASENV eq "")		||
	($DEV eq "")		||	
	($ACTION eq "")		||	
	($CONTROLLER eq "")	
   ) {
        &Usage($Purpose, "Missing parameter." );
}

#Set the SAS Environment type:
# (SAS WWIDs, port assignments, blade assignments, etc.)
&VerifySelection($SASENV, @SAS_ENVS) ||
	&Usage($Purpose, "Unrecognized SAS environment setting");
if ($SASENV eq "6Gb")   {
	require 'DB_6GbInfrastructure.pl';
}
elsif ($SASENV eq "3Gb") {
	require 'DB_3GbInfrastructure.pl';
}


#set the tty device
#print "Looking up port for device $DEV";
&VerifySelection($DEV, %CommPorts) ||
        &Usage($Purpose, "Unrecognized selection for DEV $DEV");

$TTY= $CommPorts{"$DEV"};
print "device $DEV connects via $TTY  \n";

if ( 	( $CONTROLLER ne "A" ) &&
	( $CONTROLLER ne "a" ) &&
	( $CONTROLLER ne "B" ) &&
	( $CONTROLLER ne "b" ) &&
	( $CONTROLLER ne "both") 
) {
	&Usage($Purpose, "Unknown controller $CONTROLLER for controller action $ACTION");	
} 
		


if (-e $VMWARE_LOG) {
	system("echo \"***************************\" >> $VMWARE_LOG ");
	system("echo \"CONTROLLER_MANAGEMENT_ACTION: $ACTION controller $CONTROLLER\" >> $VMWARE_LOG ");
	system("echo \"***************************\" >> $VMWARE_LOG ");
}


if ( $ACTION eq "shutdown" ) {
	$command="$ACTION $CONTROLLER noprompt";
}
elsif ( $ACTION eq "restart" ) {
	$command="$ACTION sc $CONTROLLER noprompt";
}
elsif ( $ACTION eq "restart_mc" ) {
	#$command="$ACTION restart mc $CONTROLLER noprompt";
	$command="restart mc $CONTROLLER noprompt";
}
else {
	&Usage($Purpose, "Unknown controller action $ACTION");	
}

#Open a telnet session to the specified device.
$Session = &TSession($TTY);
$TIME=`date`;
chomp($TIME);
print "$TIME: CONTROLLER MANAGEMENT ACTION: $command\n";
$Session->print("${command}");

#$Session->waitfor('/Do you want to continue? $/i');
$Session->print("y\n");
#$Session->print('');
sleep 2;

$results = $Session->getline;
if (    ($results =~ /error/) ||
	($results =~/Error/) ) {
	print $results;
}
sleep 2;
$Session->close;


############## END MAIN ##############################################

