#!/usr/bin/perl
######################################################################
# DB_CommonInfrastructure.pl
######################################################################
# Purpose:
#  Database for settings, names, etc, 
#	that do not vary among configurations.
######################################################################
# Origin: 03/2010 S.Teel
######################################################################
#
# Assumptions:
#	None
######################################################################
@SAS_ENVS = ('3Gb', '6Gb');

######################################################################
# Items for ShSAS_tools 
######################################################################
@PATHS_SELECTION = ('1', '2', '4'); # Number of logical SAS paths.

@RAID_TYPES = ('R0', 'R1', 'R3', 'R5', 'R6', 'R10', 'R50');

@VDISK_ACTIONS = ('create', 'delete');
@VOLUME_ACTIONS = ('create', 'delete', 'map');

@MAPPING_ACTIONS = (	
	'map', 'nomap', 'maponly', 'unmap', 
	'portfail', 'switchAfail', 'switchBfail', 
	'ctlrAfail', 'ctlrBfail', 'restore', 
	);



######################################################################
# Tools Login information
######################################################################
$SCS_Login 	= "automation";	# Serial console server
$SCS_PW 	= "Automate1";
$ARRAYLOG 	= "manage";	# Seahawk web-based/telnet login
$ARRAYPW	= "!manage";
$ROOT		= "root";	# Most linux devices
$ROOTPW		= "rootpwd";
$DDK40LOG	= "root";	# DDK 4.0
$DDK40PW	= "rootpwd";
$DDK41LOG	= "vmware";	# DDK 4.1
$DDK41PW	= "vmware";

######################################################################
# Device names.
######################################################################
$SCSBLADES 	= "cclass-scs1.ldev.net"; 	# Serial Console Server for Blades:
$DDK40		= "esxddk40_164009.ldev.net";	# VMware ESX DDK 4.0 development
$DDK41		= "10.10.19.237";		# VMware ESX DDK 4.1 development
$STDL380G5	= "stdl380g5.ldev.net";
$STDL380G5ILO	= "ilostdl380g5.ldev.net";
$STDL385G5ILO	= "ilostdl385g5.ldev.net";
$STDL380G6ILO	= "ilostdl380g6.ldev.net";
$STDL380G7ILO	= "ilostdl380g7.ldev.net";

######################################################################
#Access Methods:
######################################################################
$TERM		= "gnome-terminal";
#$TERM		= "xterm";
$TN 		= "telnet";
$SSH 		= "ssh";
$LOCAL		= "local";


######################################################################
# Source code management
######################################################################
@SVN_PrepBranch_ACTIONS = ( 'MAKENEW', 'CHECKOUT', 'CHECKOUTTAG', 'CHECKOUTRELEASE', 'CLONETAG' );
%SVN_REPOS = (
		'-Project-',	'-SVN Connection-',
		'hpsa', 	'https://neelix.cce.hp.com/svn/vmware/hpsa',
		'hpvsa', 	'https://neelix.cce.hp.com/svn/drivers/slate',
		'hpvsa/hpvsa', 	'svn://raptorsvn-1.cce.hp.com/projects/Ibanez/hpsa',
		'hpsa-linux',	'svn://neelix.cce.hp.com/svn/drivers/hpsa'
		);

#For each project, define whether they have a src subdir in path of repository.
%SRC_SUBDIRS = (
		'-Project-',	'-Subdir name containing source only-',
		'hpsa', 	'src',
		'hpvsa', 	'',
		'hpvsa/hpvsa', 	'',
		'hpsa-linux', 	''
		);

#Define any svn checkout directives that are needed for project:
%CHECKOUT_DIRECTIVES = (
		'-Project-',	'-Directive-',
		'hpsa', 	'',
		'hpvsa', 	'--ignore-externals ',
		'hpvsa/hpvsa', 	'',
		'hpsa-linux', 	''
		);

# Define whether repository contains a path node indicating inbox or hp (async):
%REL_TYPES = (
		'-Project-',	'-Supports release types?-',
		'hpsa', 	'yes',
		'hpvsa', 	'no',
		'hpvsa/hpvsa', 	'no',
		'hpsa-linux', 	'no'
		);

#For each project, define whether they use OS revision in path of repository.
%OS_SUBDIRS = (
		'-Project-',	'-Subdir for OS Rev?-',
		'hpsa', 	'yes',
		'hpvsa', 	'no',
		'hpvsa/hpvsa', 	'no',
		'hpsa-linux', 	'no'
		);
#Define the release type choices
@Release_Types = ('inbox', 'hp');


$SVN_docs = "http://svnbook.red-bean.com";
$GIT="/usr/local/bin/git";
# List of things git/stg should not track:
@GIT_IGNORELIST = (
			'CVS/',
			'*.ko',
			'*.o', 
			'*.tar', 
			'*.tar.gz', 
			'build.log', 
			'build/', 
			'code-check*', 
			'cscope.out', 
			'change.log', 
			'.svn/', 
			'.svn/*', 
			'patches-*/',
			'.project',
			'.cproject',
			'vendor-index*'
		);
				

######################################################################
# Development Environment
######################################################################
# Define the supported project names
@PROJECTS = ('hpsa', 'hpvsa', 'hpvsa/hpvsa', 'hpvsaPOC', 'hpsa-linux');


#Define the project directory root for each of the development environments.
%TARGET_ENVS = (
#	'-OS Target-',	"--DDK WORKSPACE PATH (partial)--",
	'esx3_5',	"NONE",
	'esx4_0',	"NONE",
	'esx4_0_u2',	"NONE",
	'esx4_1',	"NONE",
#	'esx4_1_u2',	"/proj/sysdev/WB10",
	'esx4_1_u2',	"/proj/sysdev/WB21/DDK4.1",
	'esx5_0',	"/proj/sysdev/WB20",
	'esx5_0',	"/proj/sysdev/WB21/DDK5.0",
	'esx5_0_GA',	"/proj/sysdev/WB21/DDK5.0",
	'esx5_1',	"/proj/sysdev/WB21/DDK5.0",
	'esx5_5',	"/proj/sysdev/WB30/DDK5.5",
	'esx6_0',	"/proj/sysdev/WB30/DDK6.0",
#	'esx5_5_1158842',"/proj/sysdev/WB30/DDK5.5.1158842",
	'rhel5_5',	"/proj/sysdev/WB21/DDK5.0",
	'rhel5_6',	"/proj/sysdev/WB21/DDK5.0",
	'rhel5_7',	"/proj/sysdev/WB21/DDK5.0",
	'rhel5_8',	"/proj/sysdev/WB21/DDK5.0",
	'rhel5_9',	"/proj/sysdev/WB21/DDK5.0",
	'rhel6_0',	"/proj/sysdev/WB21/DDK5.0",
	'rhel6_1',	"/proj/sysdev/WB21/DDK5.0",
	'rhel6_2',	"/proj/sysdev/WB21/DDK5.0",
	'rhel6_3',	"/proj/sysdev/WB21/DDK5.0",
	'rhel6_4',	"/proj/sysdev/WB21/DDK5.0",
	'rhel6_5',	"/proj/sysdev/WB21/DDK5.0",
	'rhel7_0',	"/proj/sysdev/WB21/DDK5.0",
	'rhel7_1',	"/proj/sysdev/WB21/DDK5.0",
#	Don't use the WB21-DDK5.1 environment for 5.1 releases yet, 
# 	since there's no differences in the 5.1 and 5.0 drivers.
#	'esx5_1',	"/proj/sysdev/WB21/DDK5.1",
	);

##############
# Required Line
###############
1;

