#!/usr/bin/perl
######################################################################
# Function DeadPathsPresent
######################################################################
# Purpose:
#     Check the given server's controller for dead paths.
# Example: 
# 	$dead = &DeadPathsPresent($server, $pw, $controller)
######################################################################
sub DeadPathsPresent {

	local($server, $pw, $num_expected_paths, $storagebox)=@_;

	$local_log="/tmp/STTools_pathscan_${storagebox}";
	$remote_log="/tmp/STTools_pathscan_${storagebox}";
	
	#&Announce("Check paths on $server ${controller}");
	$CMD = "./Expect.Remote.Cmd ${pw} ${server} " .
		"multipath -l > ${remote_log}";
	#print "Command is $CMD\n";
	system("$CMD");

	$CMD = "./Expect.Scp.File ${pw} ${server} ${remote_log} ${local_log}";
	system("$CMD");
	if (! (-e ${local_log} ) ) {
		&Announce("Failed to copy $remote_log to $local_log");
		die;
	}

	#print "storagebox = $storagebox\n";
	# Whack the remote log 
	#&Announce("clean up the temp log on $server");
	$CMD = "./Expect.Remote.Cmd ${pw} ${server} " .
		"rm -rf ${remote_log} > /tmp/junk_${storagebox}";
	#print "Command is $CMD\n";
	system("$CMD");
#

	#Detect any dead paths:
	#$CMD="grep 'state:dead' $local_log";
	#$DEADPATHS=`$CMD`;
	$PREF = "/tmp/mymulti_${storagebox}_";
	$OUTPUT = "/tmp/msa_multipath_devices_${storagebox}";
	$CMD = "rm -rf $PREF*";
	system("$CMD");
	$CMD = "cp ${local_log} /tmp/SAVEIT_${storagebox}";
	system("$CMD");
	$CMD = "rm -rf $OUTPUT";
	system("$CMD");

	$CMD = "csplit --prefix=${PREF} $local_log '/^mpath/' '{*}' > /tmp/csplit_${storagebox}.out 2>&1";
	system("$CMD");

	$M="export STORAGEBOX=${storagebox};";
	$M1="for f in ${PREF}*;";
	$M2="${OUTPUT}";
	#print "M=[$M]\n";
	#print "M1=[$M1]\n";
	#print "M2=[$M2]\n";
	$CMD = $M . $M1 . 'do if [ ! -s $f ]; then continue; fi; MSA=`grep -c ${STORAGEBOX} $f`; if [ $MSA -le 0 ]; then continue; fi; cat $f >> ' . $M2 . '; done;';

	#print "CMD = ${CMD}\n";
	system("${CMD}");

	# debug statement, remove for actual use
	#return 0;

	$CMD = "cp ${OUTPUT} ${local_log}";
	#print "MV CMD = ${CMD}\n";
	system("${CMD}");

	$CMD_ACTIVE="grep -c status=active $local_log";
	$CNT_ACTIVE=`$CMD_ACTIVE`;
	$CMD_ENABLED="grep -c status=enabled $local_log";
	$CNT_ENABLED=`$CMD_ENABLED`;
	chop $CNT_ENABLED;
	chop $CNT_ACTIVE;
	
	$changed=`date`;
	$changed=~s/\n$//g; # remove newline char
	#print "num_expected_paths = $num_expected_paths, CNT=$CNT_ACTIVE+$CNT_ENABLED\n";
	if ($num_expected_paths - ($CNT_ACTIVE + $CNT_ENABLED)) {
		$rc = 1;
		#printf("$changed %s\n", $num_expected_paths - $CNT_ACTIVE);
	}
	else {
		$rc = 0;
		#printf("%s\n", "No dead paths at $changed");
	}      

	# Whack the copy of the log
	#system("rm -rf ${local_log}");
	
	#print "Returning $rc\n";
	return $rc;
	

} # end Function DeadPathsPresent

##############
# Required Line
###############
1;

