#!/usr/bin/perl
######################################################################
# Function DoIt
######################################################################
# Purpose:
#       Execute system command and check return
######################################################################
# Origin: Scott Teel
######################################################################
sub DoIt {

        local($Command)=@_;

        #print "$Command\n";
        $result=`$Command`;
        if  ( $? != 0 ) {
                print "ERROR: from commmand $Command \n";
                return 0;
        }
        return 1;

} # end sub DoIt

##############
# Required Line
###############
1;

