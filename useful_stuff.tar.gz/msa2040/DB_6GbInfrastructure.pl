#!/usr/bin/perl
######################################################################
# DB_6GbInfrastructure.pl
######################################################################
# Purpose:
#  Keep track of Bay/Blade assignments, and 
#	SAS WWID for purposes of LUN Mapping.
#  Keep track of Serial Port assignments of 
#	devices on the various Serial Terminal servers.
######################################################################
# Origin: 03/2010 S.Teel
######################################################################
######################################################################
#
# Assumptions:
#	None
######################################################################
#

# Device names.
$Bay2		= "none";
$Bay2ILO	= "10.10.14.199";

# Serial Device link-to-port mapping
#	This specifies the connection details for each device
#	connected to serial console servers.
%CommPorts = ( 
		'-DeviceName-', 	'-Port-',
		'Falcons1ADirectTelnet','telnet 10.238.0.47',
		'F1ADT',		'telnet 10.238.0.47',
		'P20001ADT',		'telnet 10.238.0.47',
		'Falcons1BDirectTelnet','telnet 10.238.0.48',
		'F1BDT',		'telnet 10.238.0.48',
		'P20001BDT',		'telnet 10.238.0.48',
		'MSA2040ADirectTelnet', 'telnet 10.238.0.40',
		'troubleADT', 		'telnet 10.238.0.40',
		'MSA2040BDirectTelnet', 'telnet 10.238.0.41',
		'troubleBDT', 		'telnet 10.238.0.41',
		'DBP2000ADT', 		'telnet 10.238.15.37',
		'DBP2000BDT', 		'telnet 10.238.15.52',
		);

# Blade-to-Bay Mapping (via SN)
#	This specifies the blade bay number 
#	of each blade server, by serial number.
%DeviceBays =	(
		'-Bay-','-SerialNum-',
		'1',	'unknown',	
		'2',	'MXQ01602RH',
		'3',	'none',
		'4',	'none',
		'5',	'none',
		'6',	'BL460CGen9',	
		'7',	'MXQ21709MG',
		'8',	'BL660CGen9',
		'9',	'MXQ1281CDV',
		'10',	'MXQ13201CF',
		'11',	'4200818026',
		'12',	'CN71311271',
		'13',	'CN712403HX',
		'14',	'TWT01400BL',
		'15',	'none',
		'16',	'none',
		'17',	'DonDL180Gen9',
		'18',	'DonDL180Gen9-alt',
		'19',	'stdl380gen9bH220',
		'20',	'JustinGen9P441',
		'21',	'stdl380gen9bP441',
		);

#Blade Types
#	This specifies the model type of the 
#	blade server, by serial number.
%Blades = (
		'-SerialNum-',	'-Type-',
		'MXQ01602RH',	'BL460c_G6',
		'MXQ13201CF',	'BL460c_G7',
		'MXQ1281CDV',	'BL460c_G7',
		'4200818026',	'BL420c_Gen8',
		'unknown',	'BL465C_G6',		
		'4200818205',	'BL420c_Gen8',	
		'MXQ21709MG',	'BL460C_Gen8',
		'CN71311271',	'BL460C_Gen8',
		'BL660Gen9',	'BL660C_Gen9',
		'TWT01400BL',	'BL460c_G7',
		'CN712403HX',	'BL460c_Gen8',
		'DonDL180Gen9', 'DL180_Gen9',
		'DonDL180Gen9-alt', 'xxx',
		'BL460CGen9',	'BL460CGen9',
		'stdl380gen9bH220', 'DL380Gen9',
		'JustinGen9P441', 'DL380Gen9',
		'stdl380gen9bP441', 'DL380Gen9',
		);

# Blade-to-Mezzanine slot mapping 
# 	This specifies which switch gets connected.
#	The blade mezzanine slot into which the P700m controller
#	is installed maps/connects to a specific set of 
#	Blade enclosure Interconnect Bays, 
#	depending on:
#	1. the type of blade (full, half, double density)
#	2. the type of enclosure (C7000, C3000).
#
%MezzSlots = (
		'-SerialNum-',	'-P7xxm-',
		'MXQ01602RH',	'2',
		'MXQ13201CF',	'2',
		'MXQ1281CDV',	'2',
		'4200818026',	'2',
		'unknown',	'none',		
		'4200818205',	'none',	
		'MXQ21709MG',	'2',
		'CN71311271',	'2',
		'BL660CGen9',	'2',
		'TWT01400BL',	'none',
		'CN712403HX',	'2',
		'DonDL180Gen9', '2',
		'BL460CGen9',	'2',
		'stdl380gen9bH220', '2',
		'JustinGen9P441', '2',
		'stdl380gen9bP441', '2',
		);

# Interconnect devices
#	This specifies the type of interconnect
#	device loaded into each bay of the blade
#	enclosure's interconnect bays.
%Interconnects = (
		'-Bay-','-Component-',
		'1',	'Ethernet',
		'2',	'none', 
		'3',	'none',
		'4',	'none',
		'5',	'none',
		'6',	'none',
		'7',	'FlintlockA',
		'8',	'FlintlockB',
		);


# Blade-to-SAS WWID Mapping (via SN)
# 	This specifies the unique SAS IDs of each
#	of the 4 ports of each blade server's 
#	P700m controller.
%SAS_Ports = (	
		'-SerialNum-',	'-SAS-ID-Port1-,		-SAS-ID-Port2-,			-SAS-ID-Port3-,			-SAS-ID-Port4-',
		'MXQ01602RH',	'5001438006ae08f0,		5001438006ae08f1,		5001438006ae08f2,		5001438006ae08f3',
		'MXQ13201CF',	'5001438006ae0b50,		5001438006ae0b51,		5001438006ae0b52,		5001438006ae0b53',
		'MXQ1281CDV',	'5001438006ae0890,		5001438006ae0891,		5001438006ae0892,		5001438006ae0893',
		'4200818205',	'none,				none,				none,				none',
		'4200818026',	'5001438016451388,		500143801645138a,		500143801645138c,		500143801645138e',
		'BL660CGen9',	'5001438027eb5620,		5001438027eb5622,		none,				none',
		'TWT01400BL',	'none,				none,				none,				none',
		'MXQ21709MG',	'5001438022232950,		5001438022232952,		5001438022232954,		5001438022232956',
		# P731m: 'CN71311271',	'5001438023777f40,		5001438023777f41,		5001438023777f42,		5001438023777f43',
		# P721m: 'CN71311271',	'5001438022232950,		5001438022232952,		5001438022232954,		5001438022232956',
		'CN71311271',	'5001438023777f40,		5001438023777f41,		5001438023777f42,		5001438023777f43',
		'CN712403HX',	'5001438022232950,		5001438022232952,		5001438022232954,		5001438022232956',
		# P441: 'DonDL180Gen9', '5001438033367a80, 		5001438033367a84, 		none,				none',
		# P441: 'DonDL180Gen9', '5001438030586064, 		5001438030586060, 		none,				none',
		'DonDL180Gen9', '5001438032036EF0, 		5001438032036EF4, 		none,				none',
		'DonDL180Gen9-alt', '5001438033367a80, 		5001438033367a84,		none, 	none',
		'stdl380gen9bH220','500605b0039a8590, 		500605b0039a8594,		none, 	none',
		'JustinGen9P441','50014380333676b0,		50014380333676b4,		none,	none',
		'stdl380gen9bP441','5001438032f760d0, 		5001438032f760d4,		none, 	none',
		#'BL460CGen9',	'500143803091d768,		500143803091d76a,		500143803091d76c,		none',
		'BL460CGen9',	'5001438027a38a30,		5001438027a38a32,		none,	none',
		);


%Devices = (	
	'-Name-',	"-IP-,		-IPLog-,	-IP-PW-,	-SerSrv-,	-Port-,-SerLogin-,	-SerPW-",
	'Falcons1A',	"10.10.0.70,	$ARRAYLOG,	$ARRAYPW,	none,		none,	$SCS_Login,	$SCS_PW",
	'Falcons1B',	"10.10.0.71,	$ARRAYLOG,	$ARRAYPW,	none,		none,	$SCS_Login,	$SCS_PW",
	'MSA2040A',	"10.238.0.40,	$ARRAYLOG,	$ARRAYPW,	none,		none,	$SCS_Login,	$SCS_PW",
	'MSA2040B',	"10.238.0.41,	$ARRAYLOG,	$ARRAYPW,	none,		none,	$SCS_Login,	$SCS_PW",
	'Test-Blade2',	"$Bay2,		$ROOT,		$ROOTPW,	$Bay2ILO,	none,	$tlogin,	$tlpw", 
	);


# Device-Specific Settings:

# String to send to array to set no access on a LUN:
$NOACCESSSTRING =  "no-access";	# For Jets/Falcons;
#$NOACCESSSTRING =  "none";	# For Seahawks;

#Strings designating controller ports on array controllers:
# Jets/Falcons P2000 G2 SAS, etc.

# Define the controller ports for 1-path, 2-path,  and 4-path modes:
                # 1-path        2-path mode     4-path mode
@ALLARRAYPORTS  = ("A1",	"A1,B1",	"A1,A2,A3,A4,B1,B2,B3,B4");
@CTLR_A_PORTS   = ("A1",	"A1",		"A1,A2,A3,A4");	#Connections on Ctlr A
@CTLR_B_PORTS   = ("none",	"B1",		"B1,B2,B3,B4");	#Connections on Ctlr B
@SWITCH_A_PORTS = ("A1",	"A1",		"A1,B1");	#Connections to Switch A
@SWITCH_B_PORTS = ("none",	"B1",		"A2,B2");	#Connections to Switch B

#String that sets off a volume name in mapping functions
$VOLDESIGNATOR="v";	# Jets/Falcons
#$VOLDESIGNATOR="Vol";	# Seahawks

#Do SAS WWIDs need to be transformed, converting first digit to "3"?
$SASIDTRANSFORM =       0;	# no on Jets/Falcons
#$SASIDTRANSFORM =      1; 	# yes on Seahawks

#Do we need to place leading zeros into volume names?
$VOLNAMEPADDING =       1;	# yes on Jets/Falcons
#$VOLNAMEPADDING =      0;	# no on Seahawks

#Should we include "lun lun#" in every command?
$INCLUDELUNSPEC=	1;	# yes on Jets/Falcons
#$INCLUDELUNSPEC =	0; 	# no on Seahawks

#How long to wait after login to array's telnet CLI, before starting commands:
$POSTLOGINWAIT=		11;	# 10 seconds on 6 Gb arrays.
# $POSTLOGINWAIT=	1;	# 1 second on 3 Gb arrays.

############## END MAIN ##############################################

##############
# Required Line
###############
1;



