#!/usr/bin/perl
######################################################################
# Function LogIt
######################################################################
# Origin:	04/2013	S.Teel
######################################################################
sub LogIt {
        push(@INC, '/home/brace/bin/msa2040');
        require "lib_Usage.pl";
        local($LOGPATH, $MESSAGE, $SHOW)=@_;
        my( $Purpose, $STAMP);
	######################################################################
	$Purpose="Timestamp a log entry.				\n";
	$Purpose.= "Example: $0 LOGPATH MESSAGE SHOW			\n";
	$Purpose.="Params:						\n";
	$Purpose.="  LOGPATH = full pathname of logfile to append.	\n";
	$Purpose.="  MESSAGE = Message to place in log, including newline(s).\n";
	$Purpose.="  SHOW       = 1 Means also print message to STDOUT.\n";
	$Purpose.="             = 0 Don't also print message to STDOUT.\n";
	######################################################################


	# Check input parameters:
	if (    ($LOGPATH eq "--help") ||
		($LOGPATH eq "-h")
	)  {
		&Usage($Purpose, "");
	}
	if (    ($LOGPATH eq "" ) ||
		($MESSAGE eq "" ) ||
		($SHOW eq "" ) 
	)  {
	&Usage($Purpose, "Missing parameter");
	}

        if (    ($SHOW != 0 ) &&
                ($SHOW != 1) 
        ) {
		&Usage($Purpose, "Show parameter must be 1(yes) or 0(no)");
        }

	
	open(TFILE, ">>$LOGPATH") || die "Cannot open ${LOGPATH} for writing";
	$STAMP=`date`;
	$STAMP=~s/\n$//g; # remove newline char
	printf( TFILE "%s: %s\n", $STAMP, $MESSAGE);
	close TFILE;
	if ($SHOW) {
		printf("%s: %s\n", $STAMP, $MESSAGE);
	}

} # end sub LogIt

##############
# Required Line
###############
1;

