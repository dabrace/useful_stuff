#!/usr/bin/perl
######################################################################
# FailoverTesting
######################################################################
my $Purpose =	"Cause path failovers on external array-connected servers\n";
$Purpose .=	"by periodically restarting the external controllers.	\n"; 
$Purpose .=	"Usage: 						\n";
$Purpose .=	"$0 SASENV ACTION ARRAYNAME GAP CYCLES TARGET SERVER PW VMHBA CHECKRATE\n";
$Purpose .=	"\t Shutdown or restart the Storage Processors on ARRAYNAME\n";
$Purpose .=	"\t Wait GAP seconds between each restart or shutdown.	\n";
$Purpose .=	"\t Do this up to CYCLES times.				\n";
$Purpose .=	"\t\t  							\n";
$Purpose .=	"\t Where:						\n";
$Purpose .=	"\t\t SASENV	 = 3Gb|6Gb				\n";
$Purpose .=	"\t\t ACTION     = restart|shutdown 			\n";
$Purpose .=	"\t\t ARRAYNAME  = nickname of Array controller connection\n";
$Purpose .=	"\t\t	defined in DB_*config file, selected by SASENV parameter.\n";
$Purpose .=	"\t\t GAP        = minimum seconds between each storage processor restart/shutdown\n";
$Purpose .=	"\t\t CYCLES     = total number of times to do restart/shutdown\n";
$Purpose .=	"\t\t TARGET	 = A|B|BOTH controller to take action against\n";
$Purpose .=	"\t\t SERVER	 = ipaddres of ESXi test server to check paths on\n";
$Purpose .=	"\t\t PW	 = root password on that server\n";
$Purpose .=	"\t\t VMHBA 	 = controller name on server to monitor.\n";
$Purpose .=	"\t\t CHECKRATE  = # of seconds between path checks on remote server.\n";
$Purpose .=	"\t\t STORAGEBOX = MSA || P2000.\n";

$Purpose .=	"\t\t NOTE: if ACTION is shutdown, GAP time is halved	\n";
$Purpose .=	"\t\t NOTE: if CONTROLLER is BOTH, shutdown or restart action\n";
$Purpose .=	"\t\t             will alternate between the controllers\n";
$Purpose .=	"\t\t to determine when controller should be restarted	\n";
$Purpose .=	"\t Samples:						\n";
$Purpose .=	"\t\t $0 6Gb restart F1ADT 90 100 B 10.238.4.235 rootpwd  vmhba1 10\n";
$Purpose .=	"\t\t\t Restarts controller B, at most every 90 seconds	\n";
$Purpose .=	"\t\t\t (total of 10 times) on the array nicknamed F1ADT in DB_* file\n";
$Purpose .=	"\t\t\t Paths on server 10.238.4.235, controller vmhba1 will be monitored\n";
$Purpose .=	"\t\t\t and failovers won't start until all paths are active.\n";
$Purpose .=	"\t\t  							\n";
$Purpose .=	"\t\t\t Depends on Perl program ShSAS_Controllers.pl	\n";
$Purpose .=	"\t\t  							\n";
######################################################################
# Origin: 06/2009 S.Teel
######################################################################
#
# Assumptions:
#	Perl Program ShSAS_Controllers.pl is available.
#	Perl Program ShSAS_Controllers.pl has same CommPorts definitions.
######################################################################
#
# Some important Vars:

push(@INC, '/home/brace/bin/msa2040');
require 'lib_Announce.pl';
require 'lib_Usage.pl';
require 'lib_VerifySelection.pl';
require 'lib_DeadPathsPresent.pl';
require 'DB_CommonInfrastructure.pl';

$MIN_RECOVERY_TIME = 180; # 35 seconds on P2000 controllers to reboot.
$MAX_WAIT_FOR_INITIAL_CONDITIONS = 120;
$MAX_PATH_CONDITION_WAIT = 120;
$MAX_ARRAY_MGMT_RECOVERY_TIME = 200;
$MAX_END_CYCLE_PATH_RECOVERY_TIME = 600;
$CMD_WORK_TIME = 4;

$LOGFILE = "/proc/vmware/log";

# Get the parameters
( 
	$SASENV,
	$ACTION,
	$TTY,
	$GAP,
	$CYCLES,
	$TARGET,
	$SERVER,
	$PW,
	$VMHBA,
	$CHECKRATE,
	$STORAGEBOX,
)	=@ARGV;

# Check parameters:
if (	($SASENV eq "")		||
	($ACTION eq "")		||
	($TTY eq "")		||
	($GAP eq "")		||
	($CYCLES eq "")		||
	($TARGET eq "")		||	
	($SERVER eq "")		||
	($PW eq "")		||
	($VMHBA eq "")		||
	($CHECKRATE eq "")	||
	($STORAGEBOX eq "")
   ) {
	&Usage($Purpose, "Some parameter is blank.");
}


#Set the SAS Environment type:
# (SAS WWIDs, port assignments, blade assignments, etc.)
&VerifySelection($SASENV, @SAS_ENVS) ||
	&Usage($Purpose, "Unrecognized SAS environment setting");
if ($SASENV eq "6Gb")   {
	require 'DB_6GbInfrastructure.pl';
}
elsif ($SASENV eq "3Gb") {
	require 'DB_3GbInfrastructure.pl';
}


# Verify selection of connection name:
&VerifySelection($TTY, %CommPorts) || 
	&Usage($Purpose, "Unknown selection for tty/connection name: $TTY" );

if (	($ACTION ne "shutdown")	&&
	($ACTION ne "restart")	
   ) {
	&Usage($Purpose,  "Unknown Action $ACTION");
        die($USAGE);
}
if ($ACTION eq "shutdown") {
	$command=$ACTION;
	if ($GAP < $MIN_RECOVERY_TIME) {
		&Usage($Purpose, "$GAP seconds is too short. Probably need at least $MIN_RECOVERY_TIME seconds.");
	}
}
else {
	$command="restart";
	if ($GAP < $MIN_RECOVERY_TIME) {
		&Usage($Purpose, "$GAP seconds is too short. Probably need at least $MIN_RECOVERY_TIME seconds.");
	}
}
if (	($TARGET ne "A")	&&
	($TARGET ne "B")	&&
	($TARGET ne "BOTH")	
   ) {
	&Usage($Purpose,  "Illegal value for TARGET parameter $TARGET");
}



print "---------------------------------------- \n";
print " $ACTION controllers on an external array \n";
print "  -Attempt $ACTION no more often than $GAP seconds.\n";
print "  -Minimum recovery time is $MIN_RECOVERY_TIME secs\n";
print "  -Execute $CYCLES times			\n";
print "  -Execute $ACTION against $TARGET controller(s)\n";
print "  -Check paths on $SERVER controller $VMHBA every $CHECKRATE seconds\n";
print "---------------------------------------- \n";
sleep 2;

$TIME=`date`;
chomp($TIME);
&Announce("Starting $CYCLES cycles of $ACTION every $GAP seconds at $TIME");


# Check initial conditions.
# We assume that both controllers are up
# and that all paths are active 
&TimeStampedMsg("INITIAL CONDITIONS CHECK: Checking that all paths are online");
if (&Wait_for_Path_Condition("all_paths_active", $MAX_WAIT_FOR_INITIAL_CONDITIONS,
	$SERVER, $PW, $VMHBA)) {
	&TimeStampedMsg("Initial conditions check passed: all paths active.");
} 
else {
	die("Initial conditions check failed: dead paths present after waiting " .
		" $MAX_WAIT_FOR_INITIAL_CONDITIONS seconds.\n");
}

for ($i=1; $i <= $CYCLES; $i++ ) {	

	$reset_cycle = 0;
	
	# Which controller will we restart this cycle?
	$CONTROLLER=$TARGET;
	if ($TARGET eq "BOTH") {
		if (($i % 2) != 0) {
			$CONTROLLER="b";
		}
		else {
			$CONTROLLER="a";
		}
	}

		
	# Do the restart or shutdown
	$TIME=`date`;
	chomp($TIME);
	&Announce("Cycle #$i: $ACTION $CONTROLLER at $TIME");
	$CMD="./ShSAS_Controllers.pl $SASENV $TTY $command $CONTROLLER";
	print "Command is $CMD\n";
	system("$CMD");
	
	## Allow command some time to work
	&TimeStampedMsg("Waiting $CMD_WORK_TIME seconds for command to work...");
	sleep $CMD_WORK_TIME;
	
	# Make sure we actually see some dead paths after the shutdown or restart.
	if (!&Wait_for_Path_Condition("some_paths_dead",
		$MAX_PATH_CONDITION_WAIT, $SERVER, $PW, $VMHBA)) {
		&TimeStampedMsg("shutdown or restart didn't result in any dead paths " .
			" within $MAX_PATH_CONDITION_WAIT seconds.");
		&TimeStampedMsg("Cycle #$i: ARRAY $TTY is not responding to shutdown/restart commands");
		&TimeStampedMsg("Cycle #$i: Try RECOVERY of $TTY by resetting management controllers");

		die("ARRAY $TTY is not responding to shutdown/restart commands, I'm outta here!");

		$CMD="./ShSAS_Controllers.pl $SASENV $TTY restart_mc both";
		system("$CMD");
		&TimeStampedMsg("Waiting $MAX_ARRAY_MGMT_RECOVERY_TIME seconds for management controllers to reset.");
		sleep $MAX_ARRAY_MGMT_RECOVERY_TIME;
		$reset_cycle = 1; # this cycle didn't work, we have to repeat it 
	}

	# Shutdowns have to bring the controller back up 
	if ($ACTION eq "shutdown") {
		&TimeStampedMsg("Cycle #$i: Restoring $TTY $CONTROLLER at $TIME");
		$CMD="./ShSAS_Controllers.pl $SASENV $TTY restart $CONTROLLER";
		system("$CMD");
		
		# Wait for restart to work:
		if (&Wait_for_Path_Condition("all_paths_active", $MAX_PATH_CONDITION_WAIT, $SERVER, $PW, $VMHBA)) {
			&TimeStampedMsg("all paths active after restoring $TTY $CONTROLLER.");
		} 
		else {
			&TimeStampedMsg("Controller $TTY $CONTROLLER did not recover after shutdown/restart.");
			&TimeStampedMsg("Cycle #$i: Try recovery of array $TTY by resetting management controllers");

			&LogErrors("$TIME: Controller $TTY $CONTROLLER did not recover after shutdown/restart.");
			die("Controller $TTY $CONTROLLER did not recover after shutdown/restart.");
	
			$CMD="./ShSAS_Controllers.pl $SASENV $TTY restart_mc both";
			system("$CMD");
			&TimeStampedMsg("Waiting $MAX_ARRAY_MGMT_RECOVERY_TIME seconds for management controllers to recover");
			sleep $MAX_ARRAY_MGMT_RECOVERY_TIME;
			$reset_cycle = 1; # this cycle didn't work, we have to repeat it 
			if (&Wait_for_Path_Condition("all_paths_active", $MAX_PATH_CONDITION_WAIT,
				$SERVER, $PW, $VMHBA)) {
				&TimeStampedMsg("all paths active after recovery.");
			}
			else {
				&TimeStampedMsg("Paths never recovered after array $TTY recovery attempt.");
				die("Giving up.\n");
			}


		}
	}
	else { # Recovering from restart
		&TimeStampedMsg("Waiting $MIN_RECOVERY_TIME seconds for controller to start recovering");
		sleep $MIN_RECOVERY_TIME;
	}

	if ($reset_cycle) {
		$i--; # This cycle didn't work, we need to repeat it. 
	}
	else {
		# sleep for the rest of the cycle
		$REMAINING = $GAP - $CMD_WORK_TIME - $MIN_RECOVERY_TIME;
		&TimeStampedMsg("Sleeping for the rest of this cycle. ($REMAINING secs remaining)");
		if ($REMAINING >  0) {
			sleep ($REMAINING); 
		}
	}


	# Paths must all be recovered before we start next cycle.
	&TimeStampedMsg("Cycle #$i: Checking that all paths have recovered");
	if (&Wait_for_Path_Condition("all_paths_active",
		$MAX_END_CYCLE_PATH_RECOVERY_TIME, $SERVER, $PW, $VMHBA)) {
		&TimeStampedMsg("all paths fully recovered at end of cycle.");
	} 
	else {
		&TimeStampedMsg("Some paths didn't recover at end of cycle after waiting " .
			"$MAX_END_CYCLE_PATH_RECOVERY_TIME seconds.");
		die("Giving up.\n");
	}
	
} #next CYCLE

$TIME=`date`;
chomp($TIME);
&Announce("Finished $CYCLES cycles at $TIME");


############## END MAIN ##############################################
######################################################################
## Function LogErrors
#######################################################################
sub LogErrors {
	#
	#
	local ($msg) = @_;

	my($time);

	$time=`date`;
	chomp($time);

	$SERVER = "Dracula";
	$CONTROLLER = "mustard";
	$ERR_FILE="/tmp/multipath_failover_errors_${SERVER}_${CONTROLLER}.log";
	open(err_fh, ">${ERR_FILE}") || die "Couldn't open ${ERR_FILE}";
	print err_fh "$time: $msg\n" || die "Could not WRITE FILE";
	close err_fh;
}

######################################################################
## Function TimeStampedMsg
#######################################################################
## Purpose:
#	Show the given message with current timestamp.
#######################################################################
sub TimeStampedMsg {
	#
	#
	local ($msg) = @_;

	my($time);

	$time=`date`;
	chomp($time);
	print "$time: $msg\n";
}

######################################################################
## Function Wait_for_Path_condition
#######################################################################
## Purpose:
##       Wait until the given condition happens, 
##	or the max wait happens.
##	If we hit condition before max_wait, return true(1).
#	If we hit max wait before condition, return false(0).
#	Condition may be:
#		all_paths_active
#		some_paths_dead
#######################################################################
sub Wait_for_Path_Condition {
	#
	#
	local ($condition, $maxwait, $server, $pw, $controller) = @_;

	my($time_elapsed);

	if ( 	($condition ne "all_paths_active")	&&
		($condition ne "some_paths_dead")	
	   ) {
		&Usage("Wait_for_Path_Condition:",  "Unknown condition $condition");
	        return 0;
	}
	
	$TIME=`date`;
	chomp($TIME);
	&TimeStampedMsg("Waiting for path condition: $condition on server $server controller $controller"); 
	$time_elapsed = 0;
	$CONDITION_TRUE = 0;
	do {
		$DEADPATHS = &DeadPathsPresent( $SERVER, $PW, $VMHBA, $STORAGEBOX);
		#debug statement, remove for actual use
		#return 0;
		if (	($condition eq "all_paths_active") &&
			($DEADPATHS < 1)
		) {
			$CONDITION_TRUE = 1;
		}
			
		elsif (	($condition eq "some_paths_dead")  &&
			($DEADPATHS > 0)
		) {
			$CONDITION_TRUE = 1;
		}
		else {
			sleep $CHECKRATE;
			$time_elapsed = $time_elapsed + 2;
		}
	} while ((!$CONDITION_TRUE) && ($time_elapsed < $maxwait));

	$TIME=`date`;
	chomp($TIME);
	if ($CONDITION_TRUE) {
		&TimeStampedMsg("Condition $condition met after $time_elapsed seconds.");
		return 1;
	}
	if ($time_elapsed >= $maxwait) {
		&TimeStampedMsg("Didn't see condition $condition within limit of $maxwait seconds");
		return 0;
	}

	# We shouldn't get here.
	die("Wait_for_Path_Condition: Unexpected execution.\n");

}
