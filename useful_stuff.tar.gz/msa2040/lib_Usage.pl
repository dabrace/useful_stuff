#!/usr/bin/perl
######################################################################
# Function Usage
######################################################################
# Purpose:
#       Show usage/purpose statement, 
#	and any error message, 
#	then die.
# Params:
#	Purpose:	traditional usage text showing how a utility is used.
#	Message:	Error message, if any, indicating why 
#			usage was incorrect.
######################################################################
# Origin: Scott Teel
######################################################################
sub Usage {

        local($Purpose, $Message)=@_;

        print "##############################\n";
        printf("%s\n", $Purpose);
        print "##############################\n";

        die( "$Message\n" );

} # end sub Usage

##############
# Required Line
###############
1;

