# useful_stuff
Notes
