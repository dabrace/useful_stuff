#include <stdio.h>


struct poop1 {
	char *a;
	char *b;
};

struct poop2 {
	char *a;
};


#define ARRAY_SIZE(a) (sizeof(a)/sizeof((a)[0]))

int main(int argc, char **argv[])
{
	struct poop1 poo1[] = {
				{"Hello", "THERE"},
				{0,}
	};

	struct poop2 poo2[] = {
				{"BYE"}
	};


	printf("ARRAY_SIZE(poo1) = %ld, ARRAY_SIZE(poo2) = %ld\n",
			ARRAY_SIZE(poo1), ARRAY_SIZE(poo2));

	return 0;
} 
