KEYWORDS: MACRO macro define template

FWIW, declarations in syscalls.h used to serve 4 purposes:
        1) syscall table initializers needed symbols declared
        2) direct calls needed the same
        3) catching mismatches between the declarations and definitions
        4) centralized list of all syscalls

(2) has been (thankfully) reduced for some time; in any case, ksys_... is used for the remaining ones.

(1) and (3) are served by syscalls.h in architectures other than x86, arm64 and s390.  On those 3 (1) is done otherwise (near the syscall table initializer) and (3) is not done at all.

I wonder if we should do something like

SYSCALL_DECLARE3(readv, unsigned long, fd, const struct iovec __user *, vec,
                 unsigned long, vlen);
in syscalls.h instead, and not under that ifdef.

Let it expand to declaration of sys_...() in generic case and, on x86, into
__do_sys_...() and __ia32_sys_...()/__x64_sys_...(), with types matching what SYSCALL_DEFINE ends up using.

Similar macro would cover compat_sys_...() declarations.  That would restore mismatch checking for x86 and friends.  AFAICS, the cost wouldn't be terribly high - cpp would have more to chew through in syscalls.h, but it shouldn't be all that costly.  Famous last words, of course...



A similar 'trick' (that probably won't work here) is to pass the name of a #define function as a parameter to another define.
Useful for defining constants and error strings together. eg:
#define TRAFFIC_LIGHTS(x) \
        x(RED, 0, "Red") \
        x(YELLOW, 1, "Yellow) \
        x(GREEN, 2, "GREEN)

You can then do thing like:
#define x(token, value, string) token = value, enum {TRAFFIC_LIGHTS(x) NUM_LIGHTS}; #undef x #define x(token, value, string) [value] = string, const char *colours[] = {TRAFFIC_LIGHTS(x)}; #undef x to initialise constants and a name table that are always in sync.

It is also a good way to generate source lines that are over 1MB.


