#include <stdio.h>

struct u {
	union {
		struct {
			unsigned char a;
		} f1;
		struct {
			unsigned char b;
		} f2;
	} e;
};


int main(int argc, char **argv)
{

	struct u uppa_u;
	unsigned short s;
	unsigned short *ps;

	printf("sizeof uppa_u = %ld\n", sizeof(struct u));

	s = 12;

	printf("s = 0x%x\n", s);

	s = 512;
	printf("s = 0x%x\n", s);

	ps = &s;

	*ps = 512 & 0x00ff;
	printf("s = 0x%x\n", s);

	s = 12;
	*ps = 12 & 0x00ff;
	printf("s = 0x%x\n", s);

	s = 0;
	*ps = (512 & 0xFF);
	printf("1. s = 0x%x\n", s);
	*ps |= 512 &0xFF00;
	printf("2. s = 0x%x\n", s);

	s = 0;
	*ps = (1234 & 0xFF);
	printf("1. s = 0x%x\n", s);
	*ps |= 1234 &0xFF00;
	printf("2. s = 0x%x\n", s);

	printf("======65534\n");
	s = 0;
	*ps = (65534 & 0xFF);
	printf("1. s = 0x%x\n", s);
	*ps |= 65534 &0xFF00;
	printf("2. s = 0x%x\n", s);

	printf("======65535\n");
	s = 0;
	*ps = (65535 & 0xFF);
	printf("1. s = 0x%x\n", s);
	*ps |= 65535 &0xFF00;
	printf("2. s = 0x%x\n", s);

	printf("======78555\n");
	s = 0;
	*ps = (78555 & 0xFF);
	printf("1. s = 0x%x\n", s);
	*ps |= 78555 &0xFF00;
	printf("2. s = 0x%x\n", s);
	return 0;
}
