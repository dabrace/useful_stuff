#! /usr/bin/python3

import sys
import getopt
import re

global drive_letter

###############################################################################
# get options
###############################################################################
def getLogFile(argv):
        global drive_letter
        try:
            # https://docs.python.org/3/library/getopt.html
            # getopt.getopt(args, shortopts, longopts=[])
            # Assign options to opts, args is initially NULL
            opts, args = getopt.getopt(argv, "hi:o:d:", ["help", "ifile=","ofile=","drive="])

            print ("opts = ", opts)
            print ("args = ", args)

            # opt is the option, arg is the argument for the option
            # Ex1: --ifile A --ofile B
            #     opt is --ifile
            #     arg is A
            #     opt is --ofile
            #     arg is B
            # Ex2: ./getArguments.py --ifile A --ofile B --help
            #      Argument List: ['--ifile', 'A', '--ofile', 'B', '--help']
            #      opts =  [('--ifile', 'A'), ('--ofile', 'B'), ('--help', '')]
            #      args =  []
            #
            #      opt = --ifile
            #      arg = A
            #      opt = --ofile
            #      arg = B
            #      opt = --help
            #      arg = ""
            for opt, arg in opts:
                print ("================================")
                print ("opt = ", opt)
                print ("arg = ", arg)
                if opt in ("-h", "--help"):
                    print ("Help me out")
                elif opt in ("-i", "--ifile"):
                    print ("infile = ", arg)
                    in_file = arg
                elif opt in ("-o", "--ofile"):
                    print ("ofile = ", arg)
                elif opt in ("drive = ", "--drive"):
                    l = arg.replace(" ", "")
                    l = l.strip()
                    drive_letter = l
                    print ("l = [", l, "]")
                    print ("drive = [", drive_letter, "]")
                    print ("drive = [%s]" % (drive_letter))

            return in_file

        except getopt.GetoptError as e:
                print("Argument Exception: ", e)

###############################################################################
# parseLogFile
#[54776.949183] smartpqi 0000:5c:00.0: added 4:0:819:0 5000cca0b870c0660000000000000000 Direct-Access     WDC      WUSTM3240BSS200  AIO+ qd=64
###############################################################################
def parseLogFile(f):
    global drive_letter
    drives = []
    added = []
    removed = []
    added_hbtl_sas = [[0,0]]
    removed_hbtl_sas = []

    added_count = 0
    removed_count = 0

    print("Looking for: [%s]" % (drive_letter))

    for l in f:
        #print(l)
        count_sas = 0

        d = re.search(r"sd[a-z]", l)
        if d != None:
            dr = d.group(0)
            #print("d:[%s]" % (d))
            #print("dr:[%s]" % (dr))
            #print("Found drive: [%s]" % (d))
            try:
                index = drives.index(dr)
            except ValueError:
                drives.append(dr)

        if re.search('added', l): ### and re.search(drive_letter, l):
            added_count = added_count + 1
            #print("Found added")
            t = re.search('[0-9]*:[0-9]*:[0-9]*[0-9]*', l)
            hbtl = t.group(0)
            t = re.search('[0-9a-z]*', l)
            c = re.split(r'\s', l)
            sas = c[5]

            try:
                # 5000cca0a60017be0000000000000000
                # 5000cca0a5000fba0000000000000000
                sa = re.search(r"\b[0-9a-z0-9]{9,32}\b", l)
                if sa != None:
                    sas = sa.group(0)
                #print("sa[%s]" %(sa))
                try:
                    index = added.index(sas)
                except ValueError:
                    added.append(sas)
                    #print("l[%s] hbtl[%s] sas[%s]" % (l, hbtl, sas))
                    print("Added: hbtl[%s] sas[%s]" % (hbtl, sas))
                    added_hbtl_sas.append(hbtl)
                    added_hbtl_sas.append(hbtl[0], sas)
                    count_sas = count_sas + 1
            except ValueError:
                print("Added - No SAS for you[%s]" % (l))
                print("l[%s] hbtl[%s]" % (l, hbtl))

        elif re.search('removed', l): ### and re.search(drive_letter, l):
            removed_count = removed_count + 1
            #print("Found removed")
            t = re.search('[0-9]*:[0-9]*:[0-9]*[0-9]*', l)
            hbtl = t.group(0)
            c = re.split(r'\s', l)
            sas = c[5]

            try:
                sa = re.search(r"\b[0-9a-z0-9]{9,32}\b", l)
                #print("sa[%s]" %(sa))
                if sa != None:
                    sas = sa.group(0)
                try:
                    index = removed.index(sas)
                except ValueError:
                    removed.append(sas)
                    #print("l[%s] hbtl[%s] sas[%s]" % (l, hbtl, sas))
                    print("Removed: hbtl[%s] sas[%s]" % (hbtl, sas))
                    #removed_hbtl_sas.append(hbtl, sas)
            except ValueError:
                print("Removed - No SAS for you[%s] Exception {e}" % (l, str(e)))


    print("Added count = ", added_count)
    print("Removed count = ", removed_count)
    print("Drives = ", drives)
    print("Added sas = ", added)
    print("Removed sas = ", removed)
    print(added_hbtl_sas)
###############################################################################
# main function
###############################################################################
def main(argv):
    global drive_letter

    print ("Number of arguments passed: " + str(len(argv)))
    print ("Argument List:", str(argv))

    testCount = 1

    logFile = getLogFile(argv)
    print("logFile = ", logFile)

    if logFile == None:
        print("Need a log file")
        return -1

    f = open(logFile)

    if f == None:
        print("Could not open ", logFile)
        return -1

    parseLogFile(f)

    f.close()

###############################################################################
# Call function main.
###############################################################################
if __name__ == "__main__":
    main(sys.argv[1:])
