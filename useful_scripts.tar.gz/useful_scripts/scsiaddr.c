#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>
#include <stdbool.h>
#include <linux/byteorder/big_endian.h>

typedef unsigned char u8;
typedef unsigned char BYTE;
typedef unsigned long DWORD;
#define LUN_PERIPHERAL_DEVICE_ADDRESSING           0x00  //00b
#define LUN_VOLUME_SET_ADDRESSING                  0x01  //01b
#define LUN_RESERVED                               0x02  //10b
#define LUN_MASKED_PERIPHERAL_DEVICE_ADDRESSING    0x03  //11b
#define LUN_DRIVES_PER_BUS    256

typedef union _SCSI3Addr_struct {
        struct {
                u8 Dev;
                u8 Bus:6;
                u8 Mode:2;        /* b00 */
        } PeripDev;
        struct {
                u8 DevLSB;
                u8 DevMSB:6;
                u8 Mode:2;        /* b01 */
        } LogDev;
        struct {
                u8 Dev:5;
                u8 Bus:3;
                u8 Targ:6;
                u8 Mode:2;        /* b10 */
        } LogUnit;
} SCSI3Addr_struct;

void set_lun_address(SCSI3Addr_struct *address, DWORD drive)
{
   address->PeripDev.Mode = LUN_PERIPHERAL_DEVICE_ADDRESSING;
   address->PeripDev.Bus  = (BYTE)((drive / LUN_DRIVES_PER_BUS) + 1);//need to be able to handle devices located higher than 255; bus starts at 1, not 0
   address->PeripDev.Dev  = (BYTE)(drive % LUN_DRIVES_PER_BUS);
}

void print_mode(u8 mode)
{
	switch (mode) {
		case LUN_PERIPHERAL_DEVICE_ADDRESSING:
			printf("LUN_PERIPHERAL_DEVICE_ADDRESSING 0x%x\n", LUN_PERIPHERAL_DEVICE_ADDRESSING);
			break;
		case LUN_VOLUME_SET_ADDRESSING:
			printf("LUN_VOLUME_SET_ADDRESSING: 0x%x\n", LUN_VOLUME_SET_ADDRESSING);
			break;
		case LUN_RESERVED:
			printf("LUN_RESERVED: 0x%x\n", LUN_RESERVED);
			break;
		case LUN_MASKED_PERIPHERAL_DEVICE_ADDRESSING:
			printf("LUN_MASKED_PERIPHERAL_DEVICE_ADDRESSING\n");
			break;
		default:
			printf("UNKNOWN\n");
	}
}

/* reverse:  reverse string s in place */
 void reverse(char s[])
 {
     int i, j;
     char c;

     for (i = 0, j = strlen(s)-1; i<j; i++, j--) {
         c = s[i];
         s[i] = s[j];
         s[j] = c;
     }
}

char* itoa (unsigned long long  value,  char str[],  int radix)
{
    char        buf [66];
    char*       dest = buf + sizeof(buf);
    bool	sign = false;

    if (value == 0) {
        memcpy (str, "0", 2);
        return str;
    }

    if (radix < 0) {
        radix = -radix;
        if ( (long long) value < 0) {
            value = -value;
            sign = true;
        }
    }

    *--dest = '\0';

    switch (radix)
    {
    case 16:
        while (value) {
            * --dest = '0' + (value & 0xF);
            if (*dest > '9') *dest += 'A' - '9' - 1;
            value >>= 4;
        }
        break;
    case 10:
        while (value) {
            *--dest = '0' + (value % 10);
            value /= 10;
        }
        break;

    case 8:
        while (value) {
            *--dest = '0' + (value & 7);
            value >>= 3;
        }
        break;

    case 2:
        while (value) {
            *--dest = '0' + (value & 1);
            value >>= 1;
        }
        break;

    default:            // The slow version, but universal
        while (value) {
            *--dest = '0' + (value % radix);
            if (*dest > '9') *dest += 'A' - '9' - 1;
            value /= radix;
        }
        break;
    }

    if (sign) *--dest = '-';

    memcpy (str, dest, buf +sizeof(buf) - dest);
    return str;
}

int main (int ac, char **av)
{
	unsigned int x = 0x400701d7;
	unsigned int y = 0x00000001;
	unsigned int u;
	int size = sizeof(SCSI3Addr_struct);
	char buffer[256];
	u8 mode;
	u8 targ;
	u8 bus;
	u8 dev;

	SCSI3Addr_struct sa;
	SCSI3Addr_struct *psa = &sa;
	printf("sizeof SCSI3Addr = %ld\n", sizeof(SCSI3Addr_struct));
	printf("x = 0x%x\n", x);
	itoa(x, buffer, 2);
	printf("u = %s\n", buffer);
	memset(&sa, 0x4007, size);
	printf("Mode = 0x%x...", sa.LogUnit.Mode);
	print_mode(sa.LogUnit.Mode);
	printf("Bus  = 0x%x\n", sa.LogUnit.Bus);
	printf("Targ = 0x%x\n", sa.LogUnit.Targ);
	printf("Dev  = 0x%x\n", sa.LogUnit.Dev);
	printf("\n");

	u = __le32_to_cpu(x);
	itoa(u, buffer, 2);
	printf("u = %s\n", buffer);
	printf("u = 0x%x\n", u);
	memset(&sa, u, 4);
	printf("Mode = 0x%x...", sa.LogUnit.Mode);
	print_mode(sa.LogUnit.Mode);
	printf("Bus  = 0x%x\n", sa.LogUnit.Bus);
	printf("Targ = 0x%x\n", sa.LogUnit.Targ);
	printf("Dev  = 0x%x\n", sa.LogUnit.Dev);
	printf("\n");

	return 0;
}
