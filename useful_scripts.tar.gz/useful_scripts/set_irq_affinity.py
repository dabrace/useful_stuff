#! /usr/bin/python3
#
#for i in `seq 0 63`
#do
        #N=`echo $((160+(i%16))) | awk '{ printf "0x%x", $1}'`
        #T=`echo $((160+(i%16))) | awk '{ printf "%08d", $1}'`
        #echo "$((160+(i%16)))  /proc/irq/$((114+i))/smp_affinity_list           $((160+(i%16))) == $N"

        #N=`echo $((176+(i%16))) | awk '{ printf "0x%x", $1}'`

        #echo "$((176+(i%16)))  /proc/irq/$((726+i))/smp_affinity_list           $((176+(i%16))) == $N"
        #N=`echo $((224+(i%16))) | awk '{ printf "0x%x", $1}'`
        #echo "$((224+(i%16)))  /proc/irq/$((1304+i))/smp_affinity_list          $((224+(i%16))) == $N"
        #N=`echo $((240+(i%16))) | awk '{ printf "0x%x", $1}'`
        #echo "$((240+(i%16)))  /proc/irq/$((2393+i))/smp_affinity_list          $((240+(i%16))) == $N"
#done

import sys
import getopt
import ast

def do_output(cpu_bitmask, cpu_int, smp_aff, hex_cpu, binary_cpu_mask):
    print ("{0:<20} {1:<20} {2:<40} {3:>20} {4:>40}".format(cpu_bitmask, cpu_int, smp_aff, hex_cpu, binary_cpu_mask))
#
# The numbers that are added to smp_affinity_list are intrepreted as HEX values.
#
def main(argv):
    for i in range (64):
        #print (cpu)
        spec_bin = '{fill}{align}{width}{type}'.format(fill='0', align='>', width=32, type='b')
        #spec_hex = '{fill}{align}{width}{type}'.format(fill='0', align='>', width=42, type='H')
        cpu_num = 160+(i%16)
        s = "0x" + str(cpu_num)
        interrupt_num = 114+i
        #print (str(bin(cpu_num)))
        #print (str(hex(cpu_num)) + " /proc/irq/" + str(interrupt_num) + "/smp_affinity_list\t" + hex(cpu_num) + "\t" + format(cpu_num, spec_bin))
        ###print ("CPU bitmask = " + s + " (int = " + str(int(s,16)) + ") /proc/irq/" + str(interrupt_num) + "/smp_affinity_list\t" + s + "\t\t" + format(int(s,16), spec_bin))
        do_output("CPU bitmask = " + s, "(int = " + str(int(s,16)) + ")", "/proc/irq/" + str(interrupt_num) + "/smp_affinity_list", s, format(int(s,16), spec_bin))

        cpu_num = 176+(i%16)
        s = "0x" + str(cpu_num)
        interrupt_num = 726+i
        #print (str(hex(cpu_num)) + " /proc/irq/" + str(interrupt_num) + "/smp_affinity_list\t" + hex(cpu_num) + "\t" + format(cpu_num, spec_bin))
        ###print ("CPU bitmask = " + s + " (int = " + str(int(s,16)) + ") /proc/irq/" + str(interrupt_num) + "/smp_affinity_list\t" + s + "\t\t" + format(int(s,16), spec_bin))
        do_output("CPU bitmask = " + s, "(int = " + str(int(s,16)) + ")", "/proc/irq/" + str(interrupt_num) + "/smp_affinity_list", s, format(int(s,16), spec_bin))

        cpu_num = 224+(i%16)
        s = "0x" + str(cpu_num)
        interrupt_num = 1304+i
        #print (str(hex(cpu_num)) + " /proc/irq/" + str(interrupt_num) + "/smp_affinity_list\t" + hex(cpu_num) + "\t" + format(cpu_num, spec_bin))
        ###print ("CPU bitmask = " + s + " (int = " + str(int(s,16)) + ") /proc/irq/" + str(interrupt_num) + "/smp_affinity_list\t" + s + "\t\t" + format(int(s,16), spec_bin))
        do_output("CPU bitmask = " + s, "(int = " + str(int(s,16)) + ")", "/proc/irq/" + str(interrupt_num) + "/smp_affinity_list", s, format(int(s,16), spec_bin))

        cpu_num = 240+(i%16)
        s = "0x" + str(cpu_num)
        # print ("s = " + s + " cpu_num = ", int(s, 16))
        #print ("num = " + str(int(s, 16)))
        interrupt_num = 2393+i
        #print (str(hex(cpu_num)) + " /proc/irq/" + str(interrupt_num) + "/smp_affinity_list\t" + hex(cpu_num) + "\t" + format(cpu_num, spec_bin))
        ###print ("CPU bitmask = " + s + " (int = " + str(int(s,16)) + ") /proc/irq/" + str(interrupt_num) + "/smp_affinity_list\t" + s + "\t\t" + format(int(s,16), spec_bin))
        ###my_string = "CPU bitmask = " + s + " (int = " + str(int(s,16)) + ") /proc/irq/" + str(interrupt_num) + "/smp_affinity_list\t" + s + "\t\t" + format(int(s,16), spec_bin)
        do_output("CPU bitmask = " + s, "(int = " + str(int(s,16)) + ")", "/proc/irq/" + str(interrupt_num) + "/smp_affinity_list", s, format(int(s,16), spec_bin))

if __name__ == "__main__":
    main(sys.argv[1:])
