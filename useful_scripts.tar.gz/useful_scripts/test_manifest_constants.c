#include <stdio.h>
#include <asm-generic/param.h>

#define CONST1 (10 * HZ)
#define CONST2 10
int main(int argc, char **av)
{

	printf("CONST1 + 20 = %d\n", CONST1 + 20);
	printf("CONST2 * HZ + 20 = %d\n", CONST2 * HZ + 20);
	printf("(CONST2 * HZ) + 20 = %d\n", (CONST2 * HZ) + 20);
	return 0;
}
