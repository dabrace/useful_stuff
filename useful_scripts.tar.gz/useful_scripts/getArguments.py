#! /usr/bin/python3
import sys
import getopt

def main(argv):
    print ("Number of arguments passed: " + str(len(argv)))
    print ("Argument List:", str(argv))

    try:
        # https://docs.python.org/3/library/getopt.html
        # getopt.getopt(args, shortopts, longopts=[])
        # Assign options to opts, args is initially NULL
        opts, args = getopt.getopt(argv, "hi:o:", ["help", "ifile=","ofile="])
        
        print ("opts = ", opts)
        print ("args = ", args)

        # opt is the option, arg is the argument for the option
        # Ex1: --ifile A --ofile B
        #     opt is --ifile
        #     arg is A
        #     opt is --ofile
        #     arg is B
        # Ex2: ./getArguments.py --ifile A --ofile B --help
        #      Argument List: ['--ifile', 'A', '--ofile', 'B', '--help']
        #      opts =  [('--ifile', 'A'), ('--ofile', 'B'), ('--help', '')]
        #      args =  []
        #
        #      opt = --ifile
        #      arg = A
        #      opt = --ofile
        #      arg = B
        #      opt = --help
        #      arg = ""
        for opt, arg in opts:
            print ("================================")
            print ("opt = ", opt)
            print ("arg = ", arg)
            if opt in ("-h", "--help"):
                print ("Help me out")
            elif opt in ("-i", "--ifile"):
                print ("infile = ", arg)
            elif opt in ("-o", "--ofile"):
                print ("ofile = ", arg)
    except getopt.GetoptError as e:
            print("Argument Exception: ", e)

# Example usage:
# python3 ./getArguments.py -h -i INFILE -o OFILE

if __name__ == "__main__":
    main(sys.argv[1:])
