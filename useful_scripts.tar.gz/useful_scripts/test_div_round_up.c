#include <stdio.h>
#include <math.h>
#include <linux/const.h>

#define DIV_ROUND_UP __KERNEL_DIV_ROUND_UP

int main(int ac, char **av)
{
	int i = 11;
	int d = 2;
	int r = 0;

	r = DIV_ROUND_UP(i, d);
	printf("r = %d\n", r);

	// The following will crash
#if 0
	i = 11;
	d = 0;
	r = DIV_ROUND_UP(i, d);
	printf("r = %d\n", r);
#endif

	return 0;
}
