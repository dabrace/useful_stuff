#include <stdio.h>
#include <stdlib.h>

struct test_len {
	int a;
	int b[100];
};

struct test_copy_struct {
	void *p;
	void *section;
	unsigned int section_offset;
	void *iomem_addr;
} __attribute__((aligned(8)));

int main(int argc, char **av)
{
	struct test_len s;
	struct test_copy_struct tcs;
	struct test_copy_struct tcs1;

	tcs.p = malloc(1024);
	tcs.section = malloc(1024);
	tcs.section_offset = 1024;
	tcs.iomem_addr = malloc(1024);

	printf("sizeof test_len = %ld\n", sizeof(struct test_len));
	printf("&s.b[99] - &s = %lld\n", (unsigned long long)&s.b[99] -(unsigned long long)&s + sizeof(s.b[99]));

	tcs1 = tcs;

	printf("tcs.p = %p\t\t\ttcs1.p = %p\n", tcs.p, tcs1.p);
	printf("tcs.section = %p\t\t\ttcs1.section = %p\n", tcs.section, tcs1.section);
	printf("tcs.section_offset = 0x%x\t\t\ttcs1.section_offset = 0x%x\n", tcs.section_offset, tcs1.section_offset);
	printf("tcs.iomem_addr = 0x%p\t\t\ttcs1.iomem_addr = 0x%p\n", tcs.iomem_addr, tcs1.iomem_addr);

	if (tcs.p != tcs1.p)
		printf("do not match\n");
	if (tcs.section != tcs.section)
		printf("do not match\n");
	if (tcs.section_offset != tcs.section_offset)
		printf("do not match\n");
	if (tcs.iomem_addr != tcs.iomem_addr)
		printf("do not match\n");
	return 0;
}
