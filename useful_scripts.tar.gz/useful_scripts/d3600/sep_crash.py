#!/usr/bin/env python3
###############################################################################
# Crude test tool that:
# Takes a snapshot of all multipath devices on multipath server
#       * uses remote shell
# Issue commands to each IOModule on D3600.
#       * uses serial
#
# while True:
#     foreach IOModule in D3600:
#         Issue sasconnector enable to IOModule
#         Wait for all paths...If NOT all paths restored...STOP (Uses remote shell)
#         Issue sasconnector disable to IOModule
#         Wait for all paths...If NOT all paths restored...STOP (Uses remote shell)
#         Issue sasconnector enable to IOModule
#         Wait for all paths...If NOT all paths restored...STOP (Uses remote shell)
#         Issue sep crash to IOModule
#         If NOT all paths restored...STOP
###############################################################################
# 
# based on tutorials:
#   http://www.roman10.net/serial-port-communication-in-python/
#   http://www.brettdangerfield.com/post/raspberrypi_tempature_monitor_project/
#
# Uses serial paramiko, and re interfaces for serial and remote shell access.

import serial, time
import subprocess
import paramiko
import re

from datetime import datetime

###############################################################################
# log to stdout and logFile
# Prepend date and time
###############################################################################
def logOutput(message, logFile, do_stdout):
    now = datetime.now()
    dt_string = now.strftime("%m/%d/%Y %H:%M:%S")
    if (do_stdout):
        print (dt_string + ': ' + message)

    logFile.write(dt_string + ': ' + message)

###############################################################################
# Open the serial port to the I/O module.
###############################################################################
def openSerialPort(str, logFile):
    # Based on D3600 serial connection
    BAUDRATE = 115200
    ser = serial.Serial(str, BAUDRATE)
    ser.bytesize = serial.EIGHTBITS         #number of bits per bytes
    ser.parity = serial.PARITY_NONE         #set parity check: no parity
    ser.stopbits = serial.STOPBITS_ONE      #number of stop bits
    #ser.timeout = None                     #block read
    #ser.timeout = 0                        #non-block read
    ser.timeout = 2                         #timeout block read
    ser.xonxoff = False                     #disable software flow control
    ser.rtscts = False                      #disable hardware (RTS/CTS) flow control
    ser.dsrdtr = False                      #disable hardware (DSR/DTR) flow control
    ser.writeTimeout = 0                    #timeout for write

    logOutput ("Starting Up Serial Monitor\n", logFile, False)

    try:
        ser.close()
        ser.open()

    except serial.SerialException as e:
        logOutput ("error opening serial port: " + str(e), logFile, True)
        exit()

    return ser

###############################################################################
# Connect to the enclosure and obtain sasconnector information.
# The enlosure is different than the multipath server.
# The enclosure is connected using a Serial connection.
#
# In my case, I have a USB cable plugged into my D3600 IO Module and into
# a server checking the status. I get a /dev/ttyUSB<X> for each IO Module.
#
# The server runnning this python script happens to be separate from the
# multipath server.
#
# After any command is run, a "SEP: <A|B>" prompt indicates a command completion
###############################################################################
def sendSASConnectorShow(ser, logFile):

    if ser.isOpen():

        try:
            ser.flushInput()    #flush input buffer, discarding all its contents
            ser.flushOutput()   #flush output buffer, aborting current output

            ser.write(str.encode("sasconnector show\r"))
            logOutput ("write data: sasconnector show\n", logFile, False)
            time.sleep(0.5)
            numberOfLine = 0

            while True:
    
                response = ser.readline().decode()
                logOutput ("read data: " + response.strip() + '\n', logFile, False)

                numberOfLine = numberOfLine + 1
                if response.count("SEP:"):
                    break

        except serial.SerialException as e:
            print ("error communicating...: " + str(e))

    else:
        print ("serial port is not open ")

###############################################################################
# sep show
# After any command is run, a "SEP: <A|B>" prompt indicates a command completion
###############################################################################
def sendSepShow(ser, logFile):
    if ser.isOpen():

        try:
            ser.flushInput() #flush input buffer, discarding all its contents
            ser.flushOutput()#flush output buffer, aborting current output

            SASstr="sep show" + '\r'
            logOutput ("write data: " + SASstr + '\n', logFile, False)

            ser.write(str.encode(SASstr))
            time.sleep(0.5)
            numberOfLine = 0

            while True:
    
                response = ser.readline().decode()
                logOutput ("read data: " + response.strip() + '\n', logFile, False)

                numberOfLine = numberOfLine + 1
                if response.count("SEP:"):
                    break

        except serial.SerialException as e:
            print ("error communicating...: " + str(e))

    else:
        print ("serial port is not open ")

###############################################################################
# initiator show
# After any command is run, a "SEP: <A|B>" prompt indicates a command completion
###############################################################################
def sendInitiatorShow(ser, logFile):
    if ser.isOpen():

        try:
            ser.flushInput() #flush input buffer, discarding all its contents
            ser.flushOutput()#flush output buffer, aborting current output

            SASstr="initiator show" + '\r'
            logOutput ("write data: " + SASstr + '\n', logFile, False)

            ser.write(str.encode(SASstr))
            time.sleep(0.5)
            numberOfLine = 0

            while True:
    
                response = ser.readline().decode()
                logOutput ("read data: " + response.strip() + '\n', logFile, False)

                numberOfLine = numberOfLine + 1
                if response.count("SEP:"):
                    break

        except serial.SerialException as e:
            print ("error communicating...: " + str(e))

    else:
        print ("serial port is not open ")
###############################################################################
# sep crash
# sasconnector name="Port A1 SAS external connector" enable/disable
# sasconnector name="Port A2 SAS external connector" enable/disable
# sasconnector name="Port B1 SAS external connector" enable/disable
# sasconnector name="Port B2 SAS external connector" enable/disable
# After any command is run, a "SEP: <A|B>" prompt indicates a command completion
###############################################################################
def sendSepCrash(ser, logFile):
    if ser.isOpen():

        try:
            ser.flushInput() #flush input buffer, discarding all its contents
            ser.flushOutput()#flush output buffer, aborting current output

            SASstr="sep crash" + '\r'
            logOutput ("write data: " + SASstr + '\n', logFile, False)

            ser.write(str.encode(SASstr))
            time.sleep(0.5)
            numberOfLine = 0

            while True:
    
                response = ser.readline().decode(errors='ignore')
                logOutput ("read data: " + response.strip() + '\n', logFile, False)

                numberOfLine = numberOfLine + 1
                #if (numberOfLine >= 25):
                    #break
                if response.count("SEP:"):
                    break

        except serial.SerialException as e:
            print ("error communicating...: " + str(e))

    else:
        print ("serial port is not open ")

###############################################################################
# Disable/Enable sasconnector
# sasconnector name="Port A1 SAS external connector" enable/disable
# sasconnector name="Port A2 SAS external connector" enable/disable
# sasconnector name="Port B1 SAS external connector" enable/disable
# sasconnector name="Port B2 SAS external connector" enable/disable
# Note: Only A1 and B1 are actually connected to the storage controller.
#       A2 and B2 are for chaining enclosures...
#       I also noticed that storage controller FW older than 5.0 does not
#       handle multi-actuator disks very well. It uses the same wwid
#       for both actuators causing multipath to think its the same disk. This
#       caused issues. Likewise for 4KN disks.
# After any command is run, a "SEP: <A|B>" prompt indicates a command completion
###############################################################################
def sendDisableEnableSASConnector(ser, sasconnectorName, action, logFile):
    if ser.isOpen():

        try:
            ser.flushInput() #flush input buffer, discarding all its contents
            ser.flushOutput()#flush output buffer, aborting current output

            SASstr="sasconnector name=" + '"' + sasconnectorName + '"' + " " + action + '\r'
            logOutput ("write data: " + SASstr + '\n', logFile, False)

            ser.write(str.encode(SASstr))
            time.sleep(0.5)
            numberOfLine = 0

            while True:
    
                response = ser.readline().decode()
                logOutput ("read data: " + response.strip() + '\n', logFile, False)

                numberOfLine = numberOfLine + 1
                if response.count("SEP:"):
                    break

        except serial.SerialException as e:
            print ("error communicating...: " + str(e))

    else:
        print ("serial port is not open ")

###############################################################################
# Connect to server running multipath and obtain status. 
# Return count of active paths
# Uses a remote shell.
###############################################################################
def getMultipathStatus(logFile):

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect('10.238.4.50', username='root', password='')

    stdin, stdout, stderr = client.exec_command('multipath -ll')

    count=0
    for line in stdout:
        if re.search('- [0-9]*:[0-9]*:[0-9]*:[0-9]*[ ]*sd.*active.*ready', line):
            count = count + 1
            logOutput (line, logFile, False)

    client.close()

    return count

###############################################################################
# Connect to server running multipath and obtain lsscsi output. 
# Uses a remote shell.
###############################################################################
def getLSSCSI(logFile):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect('10.238.4.50', username='root', password='')

    stdin, stdout, stderr = client.exec_command('lsscsi;echo "ENDLSSCI')
   
    for line in stdout:
            logOutput (line, logFile, False)

    client.close()

###############################################################################
# main function
###############################################################################
def main():
    testCount = 1

    # Note: Only A1 and B1 are connected. A2 and B2 are for chaining JBODS.
    #       I have them both defined to remind me that only A1 and B1 are used.
    sasconnectorA1Name="Port A1 SAS external connector"
    sasconnectorA2Name="Port A2 SAS external connector"
    sasconnectorB1Name="Port B1 SAS external connector"
    sasconnectorB2Name="Port B2 SAS external connector"
    serialPortNames=["/dev/ttyUSB4", "/dev/ttyUSB0"]
    sp = [["/dev/ttyUSB4", sasconnectorB1Name, sasconnectorB2Name],
          ["/dev/ttyUSB0", sasconnectorA1Name, sasconnectorA2Name]]

    #
    # Just debug output.
    #
    for array in sp:
        print (sp)
        print ("====")
        print (sp[0])
        print (sp[1])
        print (sp[0][0], ':', sp[0][1], ':', sp[0][2])
        print (sp[1][0], ':', sp[1][1], ':', sp[1][2])

    #
    # More debug output.
    #
    print ("sp[0][0]=====================")
    print (sp[0][0])
    print (sp[0][1])
    print (sp[0][2])
    print ("sp[1][0]=====================")
    print (sp[1][0])
    print (sp[1][1])
    print (sp[1][2])
    print ("=====================")

    #
    # debug
    #
    for row in range(2):
        for col in range(1, 3, 1):
            print ("row = ", row, " col = ", col, " entry = ", sp[row][col])

    #
    # Set logFileName and open it for writeing.
    #
    logFileName = "/tmp/MPFAILOVERTESTS_sasconnector_sep_crash.txt"
    logFile = open(logFileName, "w")

    #
    # Run tests forever.
    #
    while True:
        logOutput ("====================================================\n", logFile, True)
        logOutput ("Staring test number: " + str(testCount), logFile, True)
        logOutput ("====================================================\n", logFile, True)
        for row in range(2):
            s = sp[row][0]
            ser = openSerialPort(s, logFile)
            logOutput ("Using serial row:" + str(row) + " serial port = " + s, logFile, True)
            logOutput ("Opening:" + s, logFile, True)
            initialCount = getMultipathStatus(logFile)
            logOutput ("Initial number of paths found = " + str(initialCount), logFile, True)
            sasConnectorNameOne = sp[row][1]
            sasConnectorNameTwo = sp[row][2]
            logOutput ("Connector name1 = " + sasConnectorNameOne, logFile, True)
            logOutput ("Connector name2 = " + sasConnectorNameTwo, logFile, True)

            ###################################################################
            # First disable/enable sasconnectors
            # Check multipath status before switching to the other IOModule.
            # Note: only A1 and B2 are connected to the storage controller
            ###################################################################
            sendSASConnectorShow(ser, logFile)
            getLSSCSI(logFile)
            count = getMultipathStatus(logFile)
            logOutput ("Number of paths found = " + str(count), logFile, True)

            logOutput ("Enabling:" + sasConnectorNameOne, logFile, True)
            sendDisableEnableSASConnector(ser, sasConnectorNameOne, "enable", logFile)
            #logOutput ("Enabling:" + sasConnectorNameTwo, logFile, True)
            #sendDisableEnableSASConnector(ser, sasConnectorNameTwo, "enable", logFile)
            sendSASConnectorShow(ser, logFile)
            count = getMultipathStatus(logFile)
            logOutput ("Number of paths found = " + str(count), logFile, True)

            logOutput ("Disabling:" + sasConnectorNameOne, logFile, True)
            sendDisableEnableSASConnector(ser, sasConnectorNameOne, "disable", logFile)
            #logOutput ("Disabling:" + sasConnectorNameTwo, logFile, True)
            #sendDisableEnableSASConnector(ser, sasConnectorNameTwo, "disable", logFile)
            time.sleep(15)
            logOutput ("Number of paths found = " + str(count), logFile, True)
            logOutput ("Enabling:" + sasConnectorNameOne, logFile, True)
            sendDisableEnableSASConnector(ser, sasConnectorNameOne, "enable", logFile)
            #logOutput ("Enabling:" + sasConnectorNameTwo, logFile, True)
            #sendDisableEnableSASConnector(ser, sasConnectorNameTwo, "enable", logFile)
            time.sleep(15)
            #
            # Check multipath, wait until all paths are back
            #
            # Wait for all paths to be restored
            #
            count = getMultipathStatus(logFile)
            while count < initialCount:
                count = getMultipathStatus(logFile)
                logOutput ("Number of paths found = " + str(count), logFile, True)
                time.sleep(15)

            ###################################################################
            # Now do a sep crash
            # Check multipath status before switching to the other IOModule.
            ###################################################################
            sendSepShow(ser, logFile)
            sendInitiatorShow(ser, logFile)
            time.sleep(15)
            logOutput ("----------------------------------", logFile, True)
            logOutput ("Sending sep crash to:" + s + " connector = " + '"' + sasConnectorNameOne + '"', logFile, True)
            sendSepCrash(ser, logFile)
            #
            # Check multipath, wait until all paths are back
            #
            # Wait for all paths to be restored
            #
            count = getMultipathStatus(logFile)
            while count < initialCount:
                count = getMultipathStatus(logFile)
                logOutput ("Number of paths found = " + str(count), logFile, True)
                time.sleep(15)

            #
            # Close the serial port.
            #
            logOutput ("Closing:" + s, logFile, True)
            ser.close()

        testCount += 1

###############################################################################
# Call function main.
###############################################################################
if __name__ == "__main__":
    main()
