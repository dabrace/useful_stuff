#!/usr/bin/env python3

# based on tutorials:
#   http://www.roman10.net/serial-port-communication-in-python/
#   http://www.brettdangerfield.com/post/raspberrypi_tempature_monitor_project/
#
# Uses serial and spur interfaces for serial and remote shell access.

import serial, time
import subprocess
import paramiko
import re

#import spur

SERIALPORT = "/dev/ttyUSB4"
BAUDRATE = 115200

###############################################################################
# Open the serial port to the I/O module.
###############################################################################
def openSerialPort(str, logFile):
    ser = serial.Serial(str, BAUDRATE)
    ser.bytesize = serial.EIGHTBITS         #number of bits per bytes
    ser.parity = serial.PARITY_NONE         #set parity check: no parity
    ser.stopbits = serial.STOPBITS_ONE      #number of stop bits
    #ser.timeout = None                     #block read
    #ser.timeout = 0                        #non-block read
    ser.timeout = 2                         #timeout block read
    ser.xonxoff = False                     #disable software flow control
    ser.rtscts = False                      #disable hardware (RTS/CTS) flow control
    ser.dsrdtr = False                      #disable hardware (DSR/DTR) flow control
    ser.writeTimeout = 0                    #timeout for write

    logFile.write ("Starting Up Serial Monitor\n")

    try:
        ser.close()
        ser.open()

    except serial.SerialException as e:
        print ("error opening serial port: " + str(e))
        logFile.write ("error opening serial port: " + str(e) + '\n')
        exit()

    return ser

###############################################################################
# Connect to the enclosure and obtain sasconnector information.
# The enlosure is different than the multipath server.
# The enclosure is connected using a Serial connection.
#
# In my case, I have a USB cable plugged into my D3600 IO Module and into
# a server checking the status. I get a /dev/ttyUSBX for each IO Module.
#
# The server runnning this python script happens to be separate from the
# multipath server.
###############################################################################
def sendSASConnectorShow(ser, logFile):

    if ser.isOpen():

        try:
            ser.flushInput() #flush input buffer, discarding all its contents
            ser.flushOutput()#flush output buffer, aborting current output

            ser.write(str.encode("sasconnector show\r"))
            logFile.write ("write data: sasconnector show\n")
            time.sleep(0.5)
            numberOfLine = 0

            while True:
    
                response = ser.readline().decode()
                logFile.write("read data: " + response.strip() + '\n')

                numberOfLine = numberOfLine + 1
                #if (numberOfLine >= 25):
                    #break
                if response.count("SEP:"):
                    break

        except serial.SerialException as e:
            print ("error communicating...: " + str(e))

    else:
        print ("serial port is not open ")

###############################################################################
# Reset sas
# sasconnector name="Port A1 SAS external connector" enable/disable
# sasconnector name="Port A2 SAS external connector" enable/disable
# sasconnector name="Port B1 SAS external connector" enable/disable
# sasconnector name="Port B2 SAS external connector" enable/disable
###############################################################################
def sendDisableEnableSASConnector(ser, sasconnectorName, action, logFile):
    if ser.isOpen():

        try:
            ser.flushInput() #flush input buffer, discarding all its contents
            ser.flushOutput()#flush output buffer, aborting current output

            SASstr="sasconnector name=" + '"' + sasconnectorName + '"' + " " + action + '\r'
            logFile.write ("write data: " + SASstr + '\n')

            ser.write(str.encode(SASstr))
            time.sleep(0.5)
            numberOfLine = 0

            while True:
    
                response = ser.readline().decode()
                logFile.write ("read data: " + response.strip() + '\n')

                numberOfLine = numberOfLine + 1
                #if (numberOfLine >= 25):
                    #break
                if response.count("SEP:"):
                    break

        except serial.SerialException as e:
            print ("error communicating...: " + str(e))

    else:
        print ("serial port is not open ")

###############################################################################
# Connect to server running multipath and obtain status. 
# Return count of active paths
###############################################################################
def getMultipathStatus(logFile):

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect('10.238.4.50', username='root', password='')

    stdin, stdout, stderr = client.exec_command('multipath -ll')

    count=0
    for line in stdout:
        if re.search('- [0-9]*:[0-9]*:[0-9]*:[0-9]*[ ]*sd.*active.*ready', line):
            count = count + 1
            #logFile.write (line.strip('\n'))
            logFile.write (line)

    client.close()

    return count

###############################################################################
# Connect to server running multipath and obtain lsscsi output. 
###############################################################################
def getLSSCSI(logFile):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect('10.238.4.50', username='root', password='')

    stdin, stdout, stderr = client.exec_command('lsscsi')
   
    for line in stdout:
            #logFile.write (line.strip('\n'))
            logFile.write (line)

    client.close()

###############################################################################
# main function
###############################################################################
def main():
    sasconnectorA1Name="Port A1 SAS external connector"
    sasconnectorA2Name="Port A2 SAS external connector"
    sasconnectorB1Name="Port B1 SAS external connector"
    sasconnectorB2Name="Port B2 SAS external connector"
    serialPortNames=["/dev/ttyUSB4", "/dev/ttyUSB0"]
    sp = [["/dev/ttyUSB4", sasconnectorB1Name, sasconnectorB2Name],
          ["/dev/ttyUSB0", sasconnectorA1Name, sasconnectorA2Name]]

    for array in sp:
        print (sp)
        print ("====")
        print (sp[0])
        print (sp[1])
        print (sp[0][0], ':', sp[0][1], ':', sp[0][2])
        print (sp[1][0], ':', sp[1][1], ':', sp[1][2])

    print ("sp[0][0]=====================")
    print (sp[0][0])
    print (sp[0][1])
    print (sp[0][2])
    print ("sp[1][0]=====================")
    print (sp[1][0])
    print (sp[1][1])
    print (sp[1][2])
    print ("=====================")

    # debug
    for row in range(2):
        for col in range(1, 3, 1):
            print ("row = ", row, " col = ", col, " entry = ", sp[row][col])

    logFileName = "/tmp/MPFAILOVERTESTS.txt"
    logFile = open(logFileName, "w")

    testCount = 1
    while True:
        print ("Staring test number:", testCount)
        logFile.write ("Starting test number:\n", testCount)
        for row in range(2):
            s = sp[row][0]
            ser = openSerialPort(s, logFile)
            print("Using serial row:", row, " serial port = ", s)
            print ("Opening:", s)
            initialCount = getMultipathStatus(logFile)
            print ("Initial number of paths found = ", initialCount)
            sasConnectorNameOne = sp[row][1]
            sasConnectorNameTwo = sp[row][2]
            print ("Connector name1 = ", sasConnectorNameOne)
            print ("Connector name2 = ", sasConnectorNameTwo)

            sendSASConnectorShow(ser, logFile)
            getLSSCSI(logFile)
            count = getMultipathStatus(logFile)
            print ("Number of paths found = ", count)

            print ("Enabling:", sasConnectorNameOne)
            sendDisableEnableSASConnector(ser, sasConnectorNameOne, "enable", logFile)
            print ("Enabling:", sasConnectorNameTwo)
            sendDisableEnableSASConnector(ser, sasConnectorNameTwo, "enable", logFile)
            sendSASConnectorShow(ser, logFile)
            count = getMultipathStatus(logFile)
            print ("Number of paths found = ", count)

            print ("Disabling:", sasConnectorNameOne)
            sendDisableEnableSASConnector(ser, sasConnectorNameOne, "disable", logFile)
            print ("Disabling:", sasConnectorNameTwo)
            sendDisableEnableSASConnector(ser, sasConnectorNameTwo, "disable", logFile)
            time.sleep(15)
            print ("Number of paths found = ", count)
            print ("Enabling:", sasConnectorNameOne)
            sendDisableEnableSASConnector(ser, sasConnectorNameOne, "enable", logFile)
            print ("Enabling:", sasConnectorNameTwo)
            sendDisableEnableSASConnector(ser, sasConnectorNameTwo, "enable", logFile)
            time.sleep(15)
            count = getMultipathStatus(logFile)
            while count < initialCount:
                count = getMultipathStatus(logFile)
                print ("Number of paths found = ", count)
                time.sleep(15)

            print ("Closing:", s)
            ser.close()
        ++testCount

if __name__ == "__main__":
    main()

