#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>     
#include <strings.h>    
#include <unistd.h>
#include <ctype.h>
#include <sys/types.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <scsi/scsi.h>
#include <scsi/sg.h>

int main(int argc, char *argv[])
{
    int fd;
    int i;
    sg_io_hdr_t c;
    unsigned char sense_buffer[32];
    unsigned char cdb[12];
    unsigned char buff[1024];
    int bus,status;
    
    if (argc < 2)
    {
        printf("Usage: sgAtaPass12 /dev/sg#  \n");
        return(-1);
    }
    bus = 0;

    if ((fd = open(argv[1], O_RDWR)) == -1)
    {
        printf("Unable open file\n");
        return(-1);
    }
    memset(&c, 0, sizeof(sg_io_hdr_t));
    memset(&buff, 0, sizeof(buff));
    memset(&cdb, 0,sizeof(cdb));
    memset(&sense_buffer, 0,sizeof(sense_buffer));
        //cdb[0] = 0x85; /* OPERATION CODE: 16 byte pass through */
        //cdb[1] = 4 << 1; /* PROTOCOL: PIO Data-in */
        //cdb[2] = 0x2e; /* OFF_LINE=0, CK_COND=1, T_DIR=1, BYT_BLOK=1, T_LENGTH=2 */
        //cdb[3] = 0; /* FEATURES */
        //cdb[4] = 0; /* FEATURES */
        //cdb[5] = 0; /* SECTORS */
        //cdb[6] = 1; /* SECTORS */
        //cdb[7] = 0; /* LBA LOW */
        //cdb[8] = 0; /* LBA LOW */
        //cdb[9] = 0; /* LBA MID */
        //cdb[10] = 0; /* LBA MID */
        //cdb[11] = 0; /* LBA HIGH */
        //cdb[12] = 0; /* LBA HIGH */
        //cdb[13] = 0; /* DEVICE */
        //cdb[14] = 0xA1; /* Command: ATA IDENTIFY PACKET DEVICE */;
        //cdb[15] = 0; /* CONTROL */

    //cdb[0] = 0xA1;
    //cdb[1] = 0x08;
    //cdb[2] = 0x2E;

	cdb[0] = 0xa1;
	cdb[1] = 0x08;
	cdb[2] = 0x2e;
	cdb[3] = 0;
	cdb[4] = 1;
	cdb[5] = 0;
	cdb[6] = 0;
	cdb[7] = 0;
	cdb[8] = 0;
	cdb[9] = 0xec;
	cdb[10] = 0;
	cdb[11] = 0;
    c.interface_id = 'S';
    c.dxfer_direction = SG_DXFER_FROM_DEV;
    c.cmd_len = sizeof(cdb);
    c.mx_sb_len = sizeof(sense_buffer);
    c.iovec_count = 0;
    //c.dxfer_len = sizeof(IdcData);
    c.dxfer_len = sizeof(buff);
    //c.dxferp = &buff;
    c.dxferp = buff;
    c.cmdp = cdb;
    c.sbp = sense_buffer;
    c.timeout = 0;

    status = ioctl(fd, SG_IO, &c);
    printf("Status = %d\n", status);
    for (i = 0; i < 1024; i++)
	if (buff[i] != 0)
		printf("0x%x ", buff[i]);
    printf("\n");
    return status;
}
