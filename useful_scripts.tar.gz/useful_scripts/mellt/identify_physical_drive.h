/*
 * Copyright 2016 Microsemi Corporation. All rights reserved. Microsemi and the
 * Microsemi logo are trademarks of Microsemi Corporation. All other trademarks
 * and service marks are the property of their respective owners.
 * This source code contains trade secrets of Microsemi.
 * Confidential - Need To Know Required
 */
/**
 * @file identify_physical_drive
 * @brief Header file for BMIC commands
 */
#ifndef IDENTIFY_PHYSICAL_DRIVE_H
#define IDENTIFY_PHYSICAL_DRIVE_H

//#include <align.h>
//#include <block.h>
//#include <nvram/local_nvram.h>
//#include <palapi.h>
#include <linux/types.h>

// physical drive flags
#define PDF_DRIVE_PRESENT                 0x01
#define PDF_NON_DISK_PRESENT              0x02
#define PDF_WIDE_ENABLED                  0x04
#define PDF_SYNC_ENABLED                  0x08
#define PDF_NARROW_TRAY                   0x10
#define PDF_WIDE_XFER_FAILED              0x20
#define PDF_ULTRA_ENABLED                 0x40
#define PDF_ULTRA2_ENABLED                0x80

#define BMIC_MAX_PHYS_PER_DEVICE          256

#define PATH_NUM_IDEN_PD                  8     /**< Number of paths defined in identify physical drive */
#define IPD_SER_NUM_LEN                   40

#define BEGIN_STRUCTURE_PACKING _Pragma("pack(1)")
#define END_STRUCTURE_PACKING _Pragma("pack()")
//#define BYTE unsigned char
#define HWORD __u16
#define DWORD __u32
#define QWORD __u64
#define CONN_NAME_LEN             8
#define CONN_NAME_LEN_HP          2    /**< Length of the old HP connector name */
#define DEV_SER_NUM_LEN          20
#define BOOT_LUN_ID_LEN          16    

#define BLOCK_SIZE_SHIFT_512              9
#define BLOCK_SIZE_SHIFT_4K               12
#define BLOCK_SIZE_IN_BYTES_512           (1 << BLOCK_SIZE_SHIFT_512)

#define ALIGN_UP(__VAL, __ALIGNMENT) ((__ALIGNMENT) * (((__VAL) + (__ALIGNMENT) - 1) / (__ALIGNMENT)))

#define PAL_MAX_DEVICE_PATHS     4


BEGIN_STRUCTURE_PACKING
struct device_connector_info               
{  
   BYTE mode; /**< connector mode - All dual domain connectors must have the same mode. */
   BYTE number[PAL_MAX_DEVICE_PATHS]; /**< connector number for each path */
}; 
END_STRUCTURE_PACKING


BEGIN_STRUCTURE_PACKING
struct identify_physical_drive_buffer {
   BYTE  scsi_bus;                         // 0
   BYTE  scsi_id;                          // 1
   HWORD block_size_in_bytes;              // 2
   DWORD blocks;                           // 4
   DWORD reserved_blocks;                  // 8
   BYTE  identification[40];               // 12
   BYTE  serial_number[IPD_SER_NUM_LEN];   // 52
   BYTE  firmware_revision[8];             // 92
   BYTE  inquiry_support_bits;             // 100
   BYTE  hpe_drive_stamped;                // 101
   BYTE  last_failure_reason;              // 102
   BYTE  physical_drive_flags;             // 103
   BYTE  more_physical_drive_flags;        // 104
   BYTE  scsi_lun;                         // 105
   BYTE  yet_more_physical_drive_flags;    // 106
   BYTE  even_more_physical_drive_flags;   // 107
   DWORD spi_speed_rules;                  // 108
   BYTE  phys_connector[2];
   BYTE  phys_box_on_port;                 // 114
   BYTE  phys_bay_in_box;                  // 115
   DWORD rpm;                              // 116
   BYTE  drive_type;                       // 120
   BYTE  sata_version;                     // 121
   QWORD big_total_block_count;            // 122
   QWORD ris_starting_lba;                 // 130
   DWORD ris_size;                         // 138
   BYTE  WWID[DEV_SER_NUM_LEN];            // 142
   QWORD controller_phy_map;               // 162 (not aligned to a DWORD boundary)
   BYTE  unused1[24];                      // 170
   HWORD phy_count;                        // 194
   BYTE  phy_connected_device_type[BMIC_MAX_PHYS_PER_DEVICE];  // 196
   BYTE  phy_to_drive_bay_number[BMIC_MAX_PHYS_PER_DEVICE];    // 452
   HWORD phy_to_device_index[BMIC_MAX_PHYS_PER_DEVICE];        // 708
   BYTE  box_index;                                            // 1220
   BYTE  drive_support_codes;                                  // 1221
   HWORD extra_physical_drive_flags;                           // 1222
   BYTE  negotiated_logical_link_rate[BMIC_MAX_PHYS_PER_DEVICE]; // 1224
   BYTE  phy_to_phy_map[BMIC_MAX_PHYS_PER_DEVICE];             // 1480
   BYTE  path_present_map;                 // 1736
   BYTE  path_failure_map;                 // 1737
   BYTE  active_path_number;               // 1738
   char  alt_paths_connector_name_hp[PATH_NUM_IDEN_PD][CONN_NAME_LEN_HP];   // 1739
   BYTE  alt_paths_phys_box_on_port[PATH_NUM_IDEN_PD];   // 1755
   BYTE  multi_lun_device_lun_count;       // 1763
   BYTE  min_firmware_revision[8];         // 1764
   BYTE  inquiry_unique[20];               // 1772
   BYTE  temperature_current;              // 1792
   BYTE  temperature_threshold;            // 1793
   BYTE  temperature_maximum;              // 1794
   BYTE  physical_block_size_shift_factor; // 1795
   HWORD current_qdepth_limit;             // 1796
   BYTE  reserved_switch_stuff[60];        // 1798 //currently not implemented
   HWORD power_on_hours;                   // 1858
   HWORD percent_endurance_used;           // 1860
   BYTE  drive_authentication;             // 1862
   BYTE  smart_carrier_authentication;     // 1863
   BYTE  smart_carrier_app_fw_version;     // 1864
   BYTE  smart_carrier_bl_fw_version;      // 1865
   BYTE  sanitize_support_flags;           // 1866
   BYTE  drive_key_flags;                  // 1867
   char  drive_key_name[64];               // 1868
   DWORD miscellaneous_drive_flags;        // 1932
   HWORD drive_dek_index;                  // 1936
   HWORD hba_drive_encryption_flags;       // 1938
   HWORD max_overwrite_time;               // 1940
   HWORD max_block_erase_time;             // 1942
   HWORD max_crypto_erase_time;            // 1944
   struct device_connector_info connector_info; //1946
   char  connector_name[PATH_NUM_IDEN_PD][CONN_NAME_LEN];   //1951
   BYTE  page_83_identifier[BOOT_LUN_ID_LEN]; //2015
   BYTE  maximum_link_rate[BMIC_MAX_PHYS_PER_DEVICE]; // 2031
   BYTE  negotiated_physical_link_rate[BMIC_MAX_PHYS_PER_DEVICE]; //2287
   char  box_connector_name[CONN_NAME_LEN];   //2543
   BYTE  unused2;                          // 2551
   BYTE  drive_sanitize_policy_status;     // 2552
   BYTE  padding_to_multiple_of_512[(5 * 512) - 2553];
};
END_STRUCTURE_PACKING

/* Make sure that struct identify_physical_drive_buffer is a multiple of 512 */

#define CT_ASSERT(e) extern char __assert_test_case[1 - (2*(!(e)))]

CT_ASSERT(ALIGN_UP(sizeof(struct identify_physical_drive_buffer), BLOCK_SIZE_IN_BYTES_512) == sizeof(struct identify_physical_drive_buffer));

#endif //IDENTIFY_PHYSICAL_DRIVE_H
