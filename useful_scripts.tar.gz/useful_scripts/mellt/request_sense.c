#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#define __user
#include <linux/cciss_ioctl.h>

main(int argc, char **argv)
{

	int fd, ret;
	IOCTL_Command_struct ioc;
	unsigned char buf[255];
	int i = 0;
	int flash_fd = 0;
	struct stat stat_buf;
	char *stat_data = NULL;
	int lun = 0;
	unsigned char len = 0xfc;

	// Open the controller
	fd = open(argv[1], O_RDWR);
	if (fd < 0) {
		printf("Error opening %s %s\n", argv[1], strerror(errno));
	}
	//lun=atoi(argv[2]);

	memset(&ioc, 0, sizeof(IOCTL_Command_struct));

	ioc.Request.CDBLen = 6;
	ioc.Request.Type.Type = TYPE_CMD;
	//ioc.Request.Type.Direction = XFER_WRITE;
	ioc.Request.Type.Direction = XFER_READ;
	ioc.Request.Type.Attribute = ATTR_SIMPLE;
	ioc.Request.CDB[0] = 0x03; // SCSI REQEUST SENSE
	ioc.Request.CDB[1] = 0x00;
	ioc.Request.CDB[2] = 0x00;
	ioc.Request.CDB[3] = 0x00;
	ioc.Request.CDB[4] = len;
	ioc.Request.CDB[5] = 0x00;

	memset(buf, 0, sizeof(buf));
	ioc.buf = buf;
	ioc.buf_size = len;

	ret = ioctl(fd, CCISS_PASSTHRU, &ioc);
	if(ret<0){
		printf("Error in IOCTL %s\n", strerror(errno));
		close(fd);
		exit(-1);
	}

	printf("ScsiStatus[%x] SenseLen[%d] CommandStatus[%d] ResidualCnt[%d]\n",
			ioc.error_info.ScsiStatus, ioc.error_info.SenseLen,
			ioc.error_info.CommandStatus, ioc.error_info.ResidualCnt);

	for (i = 0; i < ioc.error_info.SenseLen; i++)
		printf("0x%02hhx ", ioc.error_info.SenseInfo[i]);
	printf("\n");

	printf("Valid = 0x%02hhx\n", buf[0]);
	for (i = 0; i < len; i++)
		if (buf[i] != 0)
			printf("buf[%02d] = 0x%02hhx\n", i, buf[i]);

	for (i = 0; i < strlen(buf); i++)
		printf("SCSI Bus 	: %X\n", buf[i]);

	close(fd);
}
