/*
  * sg_bomb -- send SG_IO ioctl which causes LSI 1068 HBA to hang
  *
  *   usage: sg_bomb <device>
  *    e.g.: sg_bomb /dev/sdb
  *    e.g.: sg_bomb /dev/sg1
  *
  *   Modify offset_into_page to adjust the degree of buffer misalignment.
  */
 
#include <stdio.h>
#include <unistd.h>
#include <scsi/sg.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <scsi/scsi.h>
#include <scsi/sg.h>
 
 int main(int argc, char* argv[])
 {
     char* filename = argv[1];
     int i = 0;
     //unsigned int offset_into_page = 0xe40;
     // works: unsigned int offset_into_page = 0x0;
     // hangs: unsigned int offset_into_page = 0xf00;
     // works: unsigned int offset_into_page = 0xf04;
     unsigned int offset_into_page = 0xf04;
	//cdb[0] = 0x85; /* OPERATION CODE: 16 byte pass through */
	//cdb[1] = 4 << 1; /* PROTOCOL: PIO Data-in */
	//cdb[2] = 0x2e; /* OFF_LINE=0, CK_COND=1, T_DIR=1, BYT_BLOK=1, T_LENGTH=2 */
	//cdb[3] = 0; /* FEATURES */
	//cdb[4] = 0; /* FEATURES */
	//cdb[5] = 0; /* SECTORS */
	//cdb[6] = 1; /* SECTORS */
	//cdb[7] = 0; /* LBA LOW */
	//cdb[8] = 0; /* LBA LOW */
	//cdb[9] = 0; /* LBA MID */
	//cdb[10] = 0; /* LBA MID */
	//cdb[11] = 0; /* LBA HIGH */
	//cdb[12] = 0; /* LBA HIGH */
	//cdb[13] = 0; /* DEVICE */
	//cdb[14] = 0xA1; /* Command: ATA IDENTIFY PACKET DEVICE */;
	//cdb[15] = 0; /* CONTROL */
 
     unsigned char ata_identify_cmd[] = {0x85, (4 << 1), 0x2e, 0, 0, 0, 0x01,
         0, 0, 0, 0, 0, 0, 0, 0xa1, 0};
     unsigned char sense[32];
     memset(sense, 0, sizeof(sense));
     //unsigned char* data = valloc(0x2000); // + offset_into_page;
     unsigned char* data = malloc(0x2000); // + offset_into_page;
     struct sg_io_hdr hdr = {
         .interface_id = 'S',
         .dxfer_direction = SG_DXFER_FROM_DEV,
         .cmdp = ata_identify_cmd,
         .cmd_len = 16,
         .dxferp = data,
         .dxfer_len = 512,
         .sbp = sense,
         .mx_sb_len = sizeof(sense),
         .timeout = 5000,
     };
 
     int fd;
     int rc;

     memset(data, 0, sizeof(data));
     memset(sense, 0, sizeof(sense));

     if ((fd = open(filename, O_RDWR|O_NONBLOCK)) < 0) {
         perror("open");
         return 0;
     }
 
     rc = ioctl(fd, SG_IO, &hdr);

#define status_byte(result) (((result) >> 1) & 0x7f)
     printf("rc = %d, sg_io_hdr.resid = %d\n", rc, hdr.resid);
     printf("sg_io_hdr.status = 0x%x\n", hdr.status);
     printf("sg_io_hdr.host_status = 0x%x\n", hdr.host_status);
     printf("sg_io_hdr.masked_status = 0x%x\n", hdr.masked_status);
     printf("status_byte = 0x%x\n", status_byte(hdr.host_status));

//#define msg_byte(result)    (((result) >> 8) & 0xff)
//#define host_byte(result)   (((result) >> 16) & 0xff)
//#define driver_byte(result) (((result) >> 24) & 0xff)

//#define sense_class(sense)  (((sense) >> 4) & 0x7)
//#define sense_error(sense)  ((sense) & 0xf)
//#define sense_valid(sense)  ((sense) & 0x80)

     printf("======SENSE=====\n");
     for (i = 0; i < sizeof(sense); i++)
          printf("%hhx", sense[i]);
     printf("\n");

     printf("======DATA======\n");
     for (i = 0; i < 512; i++) {
          if ( (i % 30) == 0)
                printf("\n");
          printf("%hhx", data[i]);
     }
     printf("\n");
     printf("======DATA=Printable=====\n");
     for (i = 0; i < 512; i++) {
          if ( (i % 30) == 0)
                printf("\n");
          if (data[i] >= '0' && data[i] <= 'z')
              printf("%2c", data[i]);
          else
              printf("%02x", data[i]);
     }
     printf("\n");
     return 0;
 }
